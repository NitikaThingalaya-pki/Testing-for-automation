﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class AssaySnvPopulationFrequencyController : ControllerBase
    {
        private readonly IAssaySnvPopulationFrequencyService _assaySnvPopulationFrequencyService;

        public AssaySnvPopulationFrequencyController(IAssaySnvPopulationFrequencyService assaySnvPopulationFrequencyService)
        {
            _assaySnvPopulationFrequencyService = assaySnvPopulationFrequencyService;
        }

        /// <summary>
        /// gets the statuscode from AddAssaySnvPopulationFrequency method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssaySnvPopulationFrequency"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssaySnvPopulationFrequency")]
        [ActionName("AddAssaySnvPopulationFrequency"), Authorize]
        public async Task<ActionResult> AddAssaySnvPopulationFrequency([FromBody] AssaySnvPopulationFrequency assaySnvPopulationFrequency)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvPopulationFrequencyService.AddAssaySnvPopulationFrequency(assaySnvPopulationFrequency);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            return Ok(responseDetails);

        }


        [HttpGet]
        [Route("GetAssaySnvPopulationFrequencyById/{tabId}&{assayId}")]
        [ActionName("GetAssaySnvPopulationFrequencyById"), Authorize]
        public async Task<ActionResult> GetAssaySnvPopulationFrequencyById(int tabId, int assayId)
        {
            var driver = await _assaySnvPopulationFrequencyService.GetAssaySnvPopulationFrequencyById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("AssaySnvPopulationFrequency Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateAssaySnvPopulationFrequency")]
        [ActionName("UpdateAssaySnvPopulationFrequency"), Authorize]
        public async Task<ActionResult> UpdateAssaySnvPopulationFrequency([FromBody] AssaySnvPopulationFrequency assaySnvPopulationFrequency)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvPopulationFrequencyService.UpdateAssaySnvPopulationFrequency(assaySnvPopulationFrequency);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }

    }
}
