﻿using ODIN2_Modules;

namespace ODIN2_API.Repositories.Interface
{
    public interface IMasterUserService
    {
        Task<List<BaseResponseStatus>> AddUser(MasterUser user);
        Task<List<BaseResponseStatus>> UpdateUser(MasterUser user);
        Task<List<BaseResponseStatus>> ActivateUserById(MasterUser user);
        Task<List<BaseResponseStatus>> DeactivateUserById(MasterUser user);
        Task<List<MasterUser>> GetAllUser();
        Task<MasterUser> GetUserById(int userId);
    }
}
