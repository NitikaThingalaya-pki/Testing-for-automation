﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Repositories
{
    public class MasterUserService : BaseAsyncRepository, IMasterUserService
    {
        public MasterUserService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the user and userclientmapping 
        /// </summary>
        /// <param name="adduser"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddUser(MasterUser user)
        {
            List<BaseResponseStatus> drivers = new List<BaseResponseStatus>();
            List<BaseResponseStatus> driversmapping = new List<BaseResponseStatus>();
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spinsertuser('" + user.UserName + "','" + user.Password + "','" + user.FirstName + "','" + user.MiddleName + "','" + user.LastName + "','" + user.CreatedBy + "','" + user.RoleId + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                    if (drivers[0].StatusCode.ToString() == "200")
                    {
                        //get userid from username - if new user record is created
                        var querySQLuserid = @"select UserId from master_Users  where IsActive=true and upper(Username)='" + user.UserName.ToUpper() + "';";
                        var driverListuserid = await dbConnection.QueryAsync<MasterUser>(querySQLuserid, null, commandType: CommandType.Text);
                        var userId = driverListuserid.FirstOrDefault()?.UserId;

                        foreach (var clientId in user.ClientIdList)
                        {
                            var querySQLmapping = @"call spinsertuserclientmapping('" + userId + "','" + user.UserName + "','" + clientId + "','" + user.CreatedBy + "');";
                            var driverListmapping = await dbConnection.QueryAsync<BaseResponseStatus>(querySQLmapping, null, commandType: CommandType.Text);
                            driversmapping = driverListmapping.ToList();
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To update the user and userclientmapping
        /// </summary>
        /// <param name="updateuser"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateUser(MasterUser user)
        {
            List<BaseResponseStatus> drivers = new List<BaseResponseStatus>();
            List<BaseResponseStatus> driversdelete = new List<BaseResponseStatus>();
            List<BaseResponseStatus> driversmapping = new List<BaseResponseStatus>();

            try
            {




                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var status = "PENDING"; // PENDING  or ACTIVE (For pending - username also gets updated, but for active - username is not updated)
                    var querySQL = @"call spupdateuser('" + user.UserId + "','" + user.UserName + "','" + user.Password + "','" + user.FirstName + "','" + user.MiddleName + "','" + user.LastName + "','" + user.RoleId + "','" + user.UpdatedBy + "','" + status + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                    //get username from userid
                    var querySQLusername = @"select UserName from master_Users  where userid=" + user.UserId + ";";
                    var driverListusername = await dbConnection.QueryAsync<MasterUser>(querySQLusername, null, commandType: CommandType.Text);
                    var userName = driverListusername.FirstOrDefault()?.UserName;

                    var querySQLdelete= @"call spdeleteuserclientmapping('" + user.UserId + "');";
                    var driverListdelete = await dbConnection.QueryAsync<BaseResponseStatus>(querySQLdelete, null, commandType: CommandType.Text);
                    driversdelete = driverListdelete.ToList();

                    foreach (var clientId in user.ClientIdList)
                    {
                        var querySQLmapping = @"call spupdateuserclientmapping('" + user.UserId + "','" + userName + "','" + clientId + "','" + user.UpdatedBy + "');";
                        var driverListmapping = await dbConnection.QueryAsync<BaseResponseStatus>(querySQLmapping, null, commandType: CommandType.Text);
                        driversmapping = driverListmapping.ToList();
                    }

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To activate the user by id
        /// </summary>
        /// <param name="activateuserbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> ActivateUserById(MasterUser user)
        {
            List<BaseResponseStatus> drivers = new List<BaseResponseStatus>();
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spActivateUserById('" + user.UserId + "','" + user.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To deactivate the user by id
        /// </summary>
        /// <param name="deactivateuserbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> DeactivateUserById(MasterUser user)
        {
            List<BaseResponseStatus> drivers = new List<BaseResponseStatus>();
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spDeactivateUserById('" + user.UserId + "','" + user.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the user 
        /// </summary>
        /// <param name="getalluser"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<MasterUser>> GetAllUser()
        {
            List<MasterUser> drivers = new List<MasterUser>();
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    //var querySQL = @"select userid,username,firstname,middlename,lastname,isactive,roleid  from master_users where IsCompleteDeleted=false or IsCompleteDeleted is null;";

                    var querySQL = @"select mu.userid,mu.username,firstname,middlename,
                                    lastname,mu.isactive,mu.roleid,mr.role, mu.isaddedinactivedirectory,
                                    (select listagg(clientname, ',') from master_Userclientmapping mucm
                                    left join master_client mc on mucm.clientid=mc.clientid
                                    where userid=mu.userid) as clientnames
                                    from master_users mu 
                                    left join master_roles mr on mu.roleid=mr.roleid
                                    where IsCompleteDeleted=false or IsCompleteDeleted is null;";

                    var driverList = await dbConnection.QueryAsync<MasterUser>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To get the user by id
        /// </summary>
        /// <param name="getuserbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<MasterUser> GetUserById(int userId)
        {
            MasterUser drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                   
                    var querySQL = @"select mu.userid,mu.username,firstname,middlename,
                                    lastname,mu.isactive,mu.roleid,mr.role, isaddedinactivedirectory,
                                    (select listagg(mucm.clientid, ',') from master_Userclientmapping mucm
                                    left join master_client mc on mucm.clientid=mc.clientid
                                    where userid=mu.userid) as clientids
                                    from master_users mu 
                                    left join master_roles mr on mu.roleid=mr.roleid
                                    where IsCompleteDeleted=false or IsCompleteDeleted is null and mu.userId=" + userId + ";";


                    var driverList = await dbConnection.QueryAsync<MasterUser>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }




    }
}
