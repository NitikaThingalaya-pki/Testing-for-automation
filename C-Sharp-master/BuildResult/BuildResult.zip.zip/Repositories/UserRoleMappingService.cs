﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Repositories
{
    public class UserRoleMappingService : BaseAsyncRepository, IUserRoleMappingService
    {

        public UserRoleMappingService(IConfiguration configuration) : base(configuration)
        {
        }


        /// <summary>
        /// To add the userrolemapping 
        /// </summary>
        /// <param name="adduserrolemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddUserRoleMapping(UserRoleMapping userrolemapping)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertUserRoleMapping('" + userrolemapping.RoleModuleMappingId + "','" + userrolemapping.UserId + "','" + userrolemapping.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To update the userrolemapping 
        /// </summary>
        /// <param name="updateuserrolemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateUserRoleMapping(UserRoleMapping userrolemapping)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spUpdateUserRoleMapping('" + userrolemapping.RoleModuleMappingId + "','" + userrolemapping.UserId + "','" + userrolemapping.UserRoleMappingId + "','" + userrolemapping.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To delete the userrolemapping by id
        /// </summary>
        /// <param name="deleteuserrolemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> DeleteUserRoleMappingById(UserRoleMapping userrolemapping)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spDeleteUserRoleMappingById('" + userrolemapping.UserRoleMappingId + "','" + userrolemapping.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To get the userrolemapping 
        /// </summary>
        /// <param name="getalluserrolemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<UserRoleMapping>> GetAllUserRoleMapping()
        {
            List<UserRoleMapping> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select UserRoleMappingId,userid,rolemodulemappingid,isactive,createdby,createddate,updatedby,updateddate from master_UserRolemapping;";
                    var driverList = await dbConnection.QueryAsync<UserRoleMapping>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To add the userrolemapping by id
        /// </summary>
        /// <param name="getuserrolemappingbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<UserRoleMapping>> GetUserRoleMappingById(int userRoleMappingId)
        {
            List<UserRoleMapping> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select UserRoleMappingId,userid,rolemodulemappingid,isactive,createdby,createddate,updatedby,updateddate from master_UserRolemapping  where UserRoleMappingId=" + userRoleMappingId + ";";
                    var driverList = await dbConnection.QueryAsync<UserRoleMapping>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
    }
}
