﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface IAssaySnvConfidenceService
    {
        Task<List<BaseResponseStatus>> AddAssaySnvConfidence(AssaySnvConfidence assaySnvConfidence);
        Task<AssaySnvConfidence> GetAssaySnvConfidenceById(int tabId, int assayId);
        Task<List<BaseResponseStatus>> UpdateAssaySnvConfidence(AssaySnvConfidence assaySnvConfidence);
    }
}
