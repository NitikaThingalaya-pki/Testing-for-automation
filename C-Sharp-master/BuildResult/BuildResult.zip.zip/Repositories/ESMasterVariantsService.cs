﻿using Nest;
using ODIN2_Modules;

namespace ODIN2_API.Services
{

    public class ESMasterVariantsService : IESMasterVariantsService
    {
        private const string Index = "master_variants";
        private readonly IElasticClient _elasticClient;

        public ESMasterVariantsService(IElasticClient elasticClient)
        {
            _elasticClient = elasticClient;
        }

        public async Task<IList<MasterVariants>> GetDataByGeneId(string geneId)
        {
            var results = await _elasticClient.SearchAsync<MasterVariants>(s => s
            .Index(Index)
               .Query(q =>
                   q.Term(p => p.Gene, geneId)
               )
           );

            return results.Documents.ToList();
        }
        public async Task<IList<MasterVariants>> GetAllVariant()
        {
            var results = await _elasticClient.SearchAsync<MasterVariants>(s => s
                 //.Query(q =>
                 //    q.Term(p => p.gene, geneId)
                 //)
                 .Index(Index)
               .From(0)
                .Size(1000)
                .MatchAll()
                // .Fields(f => f.Field(fi => fi.propertyName)) //I used field to get only the value I needed rather than getting the whole document
                .SearchType(Elasticsearch.Net.SearchType.QueryThenFetch)
                .Scroll("1m")
           );

            return results.Documents.ToList();
        }


    }
}
