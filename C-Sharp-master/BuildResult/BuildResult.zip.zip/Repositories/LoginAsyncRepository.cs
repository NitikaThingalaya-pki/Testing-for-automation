﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;

namespace ODIN2_API.Repositories
{
    public class LoginAsyncRepository : BaseAsyncRepository, ILoginAsyncRepository
    {
        private IConfiguration _configuration;
        public LoginAsyncRepository(IConfiguration configuration) : base(configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// To authenticate the user - checks the username and password combination in usermaster and returns user is valid or invalid
        /// </summary>
        /// <param name="login"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AuthenticateUser(Login login)
        {
            List<BaseResponseStatus> drivers = null;
           
            try
            {
                var conn = SqlWriterConnection;
                conn.Open();

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    //var querySQL = @"select * from funcLoginAuthenticate('" + login.UserName + "','" + login.Password + "');";//pgadmin
                    var querySQL = @"call funcLoginAuthenticate('" + login.UserName + "','" + login.Password + "','','');";


                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                    if (drivers.Count > 0)
                    {
                        if (drivers[0].StatusCode.ToString() == "200")
                        {
                            BaseResponseStatus baseResponseStatus = new BaseResponseStatus();
                        
            
                            drivers[0].ResponseData = CreateToken(login);
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        ////used to generate toked based on successful login for authorizing purpose token stored in memory
        private string CreateToken(Login user)
        {
            List<Claim> claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.UserName)
            };

            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(
                _configuration.GetSection("AppSettings:Token").Value));         ////Gets token phrase from appsettings


            var cred = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(
                claims: claims,
                //expires: DateTime.Now.AddHours(15),       ////change if token needs to be shorter example AddDays(1)
                expires: DateTime.Now.AddMinutes(60), 
                signingCredentials: cred);

            var jwt = new JwtSecurityTokenHandler().WriteToken(token);

            return jwt;

        }       ////end of used to generate toked based on successful login for authorizing purpose token stored in memory

    }
}
