﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Repositories
{
    public class ClientService : BaseAsyncRepository, IClientService
    {
        public ClientService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the client master
        /// </summary>
        /// <param name="addclient"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddClient(MasterClient client)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@ClientName", client.ClientName);
                    param.Add("@CreatedBy", client.CreatedBy);
                    var querySQL = @"call spInsertClient(@ClientName ,@CreatedBy);";
                    //var querySQL = @"call spInsertClient('" + client.ClientName + "','" + client.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To update the client master
        /// </summary>
        /// <param name="updateclient"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateClient(MasterClient client)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@ClientId", client.ClientId);
                    param.Add("@ClientName", client.ClientName);
                    param.Add("@UpdatedBy", client.UpdatedBy);
                    var querySQL = @"call spUpdateClient(@ClientId,@ClientName,@UpdatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To delete the client by id
        /// </summary>
        /// <param name="deleteclientbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> DeleteClientById(MasterClient client)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@ClientId", client.ClientId);

                    param.Add("@UpdatedBy", client.UpdatedBy);
                    var querySQL = @"call spDeleteClientById(@ClientId,@UpdatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        
        /// <summary>
         /// To activate the client by id
         /// </summary>
         /// <param name="activateclientbyid"></param>
         /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> ActivateClientById(MasterClient client)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@ClientId", client.ClientId);

                    param.Add("@UpdatedBy", client.UpdatedBy);
                    var querySQL = @"call spActivateClientById(@ClientId,@UpdatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To deactivate the client by id
        /// </summary>
        /// <param name="deactivateclientbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> DeactivateClientById(MasterClient client)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@ClientId", client.ClientId);

                    param.Add("@UpdatedBy", client.UpdatedBy);
                    var querySQL = @"call spDeactivateClientById(@ClientId,@UpdatedBy);;";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To get the client master data 
        /// </summary>
        /// <param name="getallclient"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<MasterClient>> GetAllClient()
        {
            List<MasterClient> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select clientid,clientname,0 as Noofprocessedcases,isactive,createdby,createddate,updatedby,updateddate,s3foldercreated from master_client where IsCompleteDeleted=false;";
                    var driverList = await dbConnection.QueryAsync<MasterClient>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To get the active client master data 
        /// </summary>
        /// <param name="getallActiveclient"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<MasterClient>> GetAllActiveClient()
        {
            List<MasterClient> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select clientid,clientname,0 as Noofprocessedcases,isactive,createdby,createddate,updatedby,updateddate,s3foldercreated from master_client where IsCompleteDeleted=false and IsActive=true and s3foldercreated=true;";
                    var driverList = await dbConnection.QueryAsync<MasterClient>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To add the client by id
        /// </summary>
        /// <param name="getclientbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<MasterClient> GetClientById(int clientId)
        {
            MasterClient drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select clientid,clientname,0 as Noofprocessedcases,isactive,createdby,createddate,updatedby,updateddate,s3foldercreated from master_client  where ClientId=" + clientId + ";";
                    var driverList = await dbConnection.QueryAsync<MasterClient>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

    }
}
