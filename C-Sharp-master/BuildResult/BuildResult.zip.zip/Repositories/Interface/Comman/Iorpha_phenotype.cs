﻿using ODIN2_Modules.Comman;

namespace ODIN2_API.Repositories.Interface.Comman
{
    public interface Iorpha_phenotype
    {
        Task<List<orphanetphenotype>> GetAllorphanetPhenotype(string SearchGeneSymbol);
    }
}
