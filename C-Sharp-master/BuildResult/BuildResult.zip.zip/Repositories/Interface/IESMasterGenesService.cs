﻿using ODIN2_Modules;

namespace ODIN2_API.Services
{
    public interface IESMasterGenesService
    {
        Task<IList<MasterGenes>> GetDataByGeneId(string geneId);

        Task<IList<MasterGenes>> GetAllDataGene();
    }
}
