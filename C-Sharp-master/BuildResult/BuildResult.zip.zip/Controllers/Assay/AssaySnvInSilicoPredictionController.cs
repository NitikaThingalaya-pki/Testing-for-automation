﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class AssaySnvInSilicoPredictionController : ControllerBase
    {
        private readonly IAssaySnvInSilicoPredictionService _assaySnvInSilicoPredictionService;

        public AssaySnvInSilicoPredictionController(IAssaySnvInSilicoPredictionService assaySnvInSilicoPredictionService)
        {
            _assaySnvInSilicoPredictionService = assaySnvInSilicoPredictionService;
        }

        /// <summary>
        /// gets the statuscode from AddAssaySnvInSilicoPrediction method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssaySnvInSilicoPrediction"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssaySnvInSilicoPrediction")]
        [ActionName("AddAssaySnvInSilicoPrediction"), Authorize]
        public async Task<ActionResult> AddAssaySnvInSilicoPrediction([FromBody] AssaySnvInSilicoPrediction assaySnvInSilicoPrediction)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvInSilicoPredictionService.AddAssaySnvInSilicoPrediction(assaySnvInSilicoPrediction);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            return Ok(responseDetails);

        }


        [HttpGet]
        [Route("GetAssaySnvInSilicoPredictionById/{tabId}&{assayId}")]
        [ActionName("GetAssaySnvInSilicoPredictionById"), Authorize]
        public async Task<ActionResult> GetAssaySnvInSilicoPredictionById(int tabId, int assayId)
        {
            var driver = await _assaySnvInSilicoPredictionService.GetAssaySnvInSilicoPredictionById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("AssaySnvInSilicoPrediction Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateAssaySnvInSilicoPrediction")]
        [ActionName("UpdateAssaySnvInSilicoPrediction"), Authorize]
        public async Task<ActionResult> UpdateAssaySnvInSilicoPrediction([FromBody] AssaySnvInSilicoPrediction assaySnvInSilicoPrediction)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvInSilicoPredictionService.UpdateAssaySnvInSilicoPrediction(assaySnvInSilicoPrediction);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }


    }
}
