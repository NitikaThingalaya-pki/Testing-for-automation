﻿using System.Data.Common;
using System.Data.SqlClient;
using Npgsql;

namespace ODIN2_API
{
    public abstract class BaseAsyncRepository
    {
        private string sqlwriterConnectionString;
        private string sqlreaderConnectionString;
        private string databaseType;

        /// <summary>
        /// gets the connectionstring value from appsettings.json file
        /// </summary>
        /// <param name="configuration"></param>
        public BaseAsyncRepository(IConfiguration configuration)
        {
            sqlwriterConnectionString = configuration.GetSection("DBInfo:ConnectionString").Value;

            databaseType = configuration.GetSection("DBInfo:DbType").Value;
        }

        internal DbConnection SqlWriterConnection
        {
            get
            {

                //return new SqlConnection(sqlwriterConnectionString);
                return new NpgsqlConnection(sqlwriterConnectionString);
             

            }
        }

    }

}
