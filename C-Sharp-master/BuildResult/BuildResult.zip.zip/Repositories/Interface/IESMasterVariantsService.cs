﻿using ODIN2_Modules;

namespace ODIN2_API.Services
{
    public interface IESMasterVariantsService
    {
        Task<IList<MasterVariants>> GetDataByGeneId(string geneId);
        Task<IList<MasterVariants>> GetAllVariant();
    }
}
