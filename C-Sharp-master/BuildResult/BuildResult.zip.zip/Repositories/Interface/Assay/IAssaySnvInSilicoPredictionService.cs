﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface IAssaySnvInSilicoPredictionService
    {
        Task<List<BaseResponseStatus>> AddAssaySnvInSilicoPrediction(AssaySnvInSilicoPrediction assaySnvInSilicoPrediction);
        Task<AssaySnvInSilicoPrediction> GetAssaySnvInSilicoPredictionById(int tabId, int assayId);
        Task<List<BaseResponseStatus>> UpdateAssaySnvInSilicoPrediction(AssaySnvInSilicoPrediction assaySnvInSilicoPrediction);
    }
}
