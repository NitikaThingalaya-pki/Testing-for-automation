﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface IAssayViewService
    {
        Task<List<BaseResponseStatus>> AddAssayView(AssayView assayView);
        Task<List<BaseResponseStatus>> UpdateAssayView(AssayView assayView);
    }
}
