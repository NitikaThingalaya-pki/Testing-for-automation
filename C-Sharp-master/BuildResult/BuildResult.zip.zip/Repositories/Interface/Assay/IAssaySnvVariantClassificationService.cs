﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface IAssaySnvVariantClassificationService
    {
        Task<List<BaseResponseStatus>> AddAssaySnvVariantClassification(AssaySnvVariantClassification assaySnvVariantClassification);
        Task<AssaySnvVariantClassification> GetAssaySnvVariantClassificationById(int tabId, int assayId);
        Task<List<BaseResponseStatus>> UpdateAssaySnvVariantClassification(AssaySnvVariantClassification assaySnvVariantClassification);
    }
}
