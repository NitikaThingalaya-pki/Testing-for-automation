﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface
{
    public interface IAssayGeneGeneListService
    {
        Task<List<BaseResponseStatus>> AddAssayGeneGeneList(AssayGeneGeneList assayGeneGeneList);
        Task<AssayGeneGeneList> GetAssayGeneGeneListById(int tabId, int assayId);
        Task<List<BaseResponseStatus>> UpdateAssayGeneGeneList(AssayGeneGeneList assayGeneGeneList);
    }
}
