﻿using ODIN2_Modules.Comman;

namespace ODIN2_API.Repositories.Interface.Comman
{
    public interface IClinvargene
    {
        Task<List<Clinvargene>> GetAllClinvargenePhenotype(string SearchGeneSymbol);
    }
}
