﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssayGeneGeneListService : BaseAsyncRepository, IAssayGeneGeneListService
    {

        public AssayGeneGeneListService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssayGeneGeneList
        /// </summary>
        /// <param name="addAssayGeneGeneList"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssayGeneGeneList(AssayGeneGeneList assayGeneGeneList)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssayGeneGeneList(
                                    '" + assayGeneGeneList.AssayId + "'," +
                                    "'" + assayGeneGeneList.TabId + "'," +
                                    "'" + assayGeneGeneList.HPOMSDDL + "'," +
                                    "'" + assayGeneGeneList.OMIMMSDDL + "'," +
                                    "'" + assayGeneGeneList.HGMDMSDDL + "'," +
                                    "'" + assayGeneGeneList.ClinvarMSDDL + "'," +
                                    "'" + assayGeneGeneList.OrphanetMSDDL + "'," +
                                    "'" + assayGeneGeneList.HPOMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.OMIMMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.HGMDMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.ClinvarMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.OrphanetMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="getassayGeneGeneListbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<AssayGeneGeneList> GetAssayGeneGeneListById(int tabId, int assayId)
        {
            AssayGeneGeneList drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select AssayGeneGeneListId,AssayId,TabId,
                                        HPOMSDDL,OMIMMSDDL,HGMDMSDDL,ClinvarMSDDL,OrphanetMSDDL,
                                        HPOMSDDLTEXT,OMIMMSDDLTEXT,HGMDMSDDLTEXT,ClinvarMSDDLTEXT,OrphanetMSDDLTEXT,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_Gene_GeneList 
                                        where 
                                        tabId =" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<AssayGeneGeneList>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssayGeneGeneList
        /// </summary>
        /// <param name="UpdateAssayGeneGeneList"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssayGeneGeneList(AssayGeneGeneList assayGeneGeneList)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssayGeneGeneList(
                                    '" + assayGeneGeneList.AssayId + "'," +
                                    "'" + assayGeneGeneList.TabId + "'," +
                                    "'" + assayGeneGeneList.HPOMSDDL + "'," +
                                    "'" + assayGeneGeneList.OMIMMSDDL + "'," +
                                    "'" + assayGeneGeneList.HGMDMSDDL + "'," +
                                    "'" + assayGeneGeneList.ClinvarMSDDL + "'," +
                                    "'" + assayGeneGeneList.OrphanetMSDDL + "'," +
                                    "'" + assayGeneGeneList.HPOMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.OMIMMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.HGMDMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.ClinvarMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.OrphanetMSDDLTEXT + "'," +
                                    "'" + assayGeneGeneList.UpdatedBy + "');";

                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

    }
}
