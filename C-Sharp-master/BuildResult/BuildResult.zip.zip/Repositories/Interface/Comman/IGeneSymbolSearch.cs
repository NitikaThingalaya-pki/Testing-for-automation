﻿using ODIN2_Modules.Comman;

namespace ODIN2_API.Repositories.Interface.Comman
{
    public interface IGeneSymbolSearch
    {
        Task<List<GeneSymbolSearch>> GeneSymbolSearchResult(string SearchGeneSymbol);
    }
}
