﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssaySnvVariantTypeService : BaseAsyncRepository, IAssaySnvVariantTypeService
    {
        public AssaySnvVariantTypeService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssaySnvVariantType
        /// </summary>
        /// <param name="addAssaySnvVariantType"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssaySnvVariantType(AssaySnvVariantType assaySnvVariantType)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssaySnvVariantType(
                                    '" + assaySnvVariantType.AssayId + "'," + 
                                    "'" + assaySnvVariantType.TabId + "'," +
                                    "'" + assaySnvVariantType.VariantTypeDDL + "'," +
                                    "'" + assaySnvVariantType.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="getassaySnvVariantTypebyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<AssaySnvVariantType> GetAssaySnvVariantTypeById(int tabId, int assayId)
        {
            AssaySnvVariantType drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select 
                                     AssaySNVVariantTypeId,AssayId,TabId,VariantTypeDDL,
                                    CreatedBy,Createddate,UpdatedBy,Updateddate
                                    from Assay_SNV_VariantType where 
                                    tabId =" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<AssaySnvVariantType>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssaySnvVariantType
        /// </summary>
        /// <param name="UpdateAssaySnvVariantType"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssaySnvVariantType(AssaySnvVariantType assaySnvVariantType)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssaySNVVariantType(
                                    '" + assaySnvVariantType.AssayId + "'," +
                                    "'" + assaySnvVariantType.TabId + "'," +
                                    "'" + assaySnvVariantType.VariantTypeDDL + "'," +
                                    "'" + assaySnvVariantType.UpdatedBy + "');";

                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


    }
}
