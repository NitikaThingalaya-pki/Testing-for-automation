﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssaySnvInheritanceService : BaseAsyncRepository, IAssaySnvInheritanceService
    {

        public AssaySnvInheritanceService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssaySnvInheritance
        /// </summary>
        /// <param name="addAssaySnvInheritance"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssaySnvInheritance(AssaySnvInheritance assaySnvInheritance)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssaySnvInheritance(
                                    '" + assaySnvInheritance.AssayId + "'," +
                                    "'" + assaySnvInheritance.TabId + "'," +
                                    "'" + assaySnvInheritance.InheritanceMSDDL + "'," +
                                    "'" + assaySnvInheritance.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="getassaySnvInheritancebyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<AssaySnvInheritance> GetAssaySnvInheritanceById(int tabId, int assayId)
        {
            AssaySnvInheritance drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select AssaySNVInheritanceId,AssayId,TabId,
                                        InheritanceMSDDL,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_SNV_Inheritance 
                                        where 
                                        tabId =" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<AssaySnvInheritance>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssaySnvInheritance
        /// </summary>
        /// <param name="UpdateAssaySnvInheritance"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssaySnvInheritance(AssaySnvInheritance assaySnvInheritance)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssaySNVInheritance(
                                    '" + assaySnvInheritance.AssayId + "'," +
                                    "'" + assaySnvInheritance.TabId + "'," +
                                    "'" + assaySnvInheritance.InheritanceMSDDL + "'," +
                                    "'" + assaySnvInheritance.UpdatedBy + "');";

                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

    }
}
