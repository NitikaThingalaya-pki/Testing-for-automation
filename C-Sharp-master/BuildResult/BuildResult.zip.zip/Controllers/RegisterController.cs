﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class RegisterController : ControllerBase
    {
        private readonly IRegisterAsyncRepository _registerAsyncRepository;

        public RegisterController(IRegisterAsyncRepository registerAsyncRepository)
        {

            _registerAsyncRepository = registerAsyncRepository;

        }

        /// <summary>
        /// gets the statuscode from RegisterUser method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="register"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("RegisterUser")]
        public async Task<ActionResult> RegisterUser([FromBody] MasterUser register)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _registerAsyncRepository.RegisterUser(register);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

    }
}
