﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface IAssaySnvVariantTypeService
    {
        Task<List<BaseResponseStatus>> AddAssaySnvVariantType(AssaySnvVariantType assaySnvVariantType);
        Task<AssaySnvVariantType> GetAssaySnvVariantTypeById(int tabId, int assayId);
        Task<List<BaseResponseStatus>> UpdateAssaySnvVariantType(AssaySnvVariantType assaySnvVariantType);
    }
}
