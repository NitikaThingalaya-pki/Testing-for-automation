﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;


namespace ODIN2_API.Repositories.Assay
{
    public class AssaySnvConfidenceService : BaseAsyncRepository, IAssaySnvConfidenceService
    {
        public AssaySnvConfidenceService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssaySnvConfidence
        /// </summary>
        /// <param name="addAssaySnvConfidence"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssaySnvConfidence(AssaySnvConfidence assaySnvConfidence)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssaySnvConfidence(
                                    '" + assaySnvConfidence.AssayId + "'," +
                                    "'" + assaySnvConfidence.TabId + "'," +
                                    "'" + assaySnvConfidence.CallQualityDDL + "'," +
                                    "'" + assaySnvConfidence.CallQualityValue + "'," +
                                    "'" + assaySnvConfidence.VariantFilterDDL + "'," +
                                    "'" + assaySnvConfidence.MappingQualityDDL + "'," +
                                    "'" + assaySnvConfidence.MappingQualityValue + "'," +
                                    "'" + assaySnvConfidence.GenotypeQualityDDL + "'," +
                                    "'" + assaySnvConfidence.GenotypeQualityValue + "'," +
                                    "'" + assaySnvConfidence.ReadDepthDDL + "'," +
                                    "'" + assaySnvConfidence.ReadDepthValue + "'," +
                                    "'" + assaySnvConfidence.AltPercentageDDL + "'," +
                                    "'" + assaySnvConfidence.AltPercentageValue + "'," +
                                    "'" + assaySnvConfidence.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="getassaySnvConfidencebyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<AssaySnvConfidence> GetAssaySnvConfidenceById(int tabId, int assayId)
        {
            AssaySnvConfidence drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select 
                                     AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
                                     VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
                                    ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
                                    ,CreatedBy,Createddate,UpdatedBy,Updateddate 
                                    from Assay_SNV_Confidence where 
                                    tabId =" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssaySnvConfidence
        /// </summary>
        /// <param name="UpdateAssaySnvConfidence"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssaySnvConfidence(AssaySnvConfidence assaySnvConfidence)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssaySNVConfidence(
                        '" + assaySnvConfidence.AssayId + "'," +
                        "'" + assaySnvConfidence.TabId + "'," +
                        "'" + assaySnvConfidence.CallQualityDDL + "'," +
                        "'" + assaySnvConfidence.CallQualityValue + "'," +
                        "'" + assaySnvConfidence.VariantFilterDDL + "'," +
                        "'" + assaySnvConfidence.MappingQualityDDL + "'," +
                        "'" + assaySnvConfidence.MappingQualityValue + "'," +
                        "'" + assaySnvConfidence.GenotypeQualityDDL + "'," +
                        "'" + assaySnvConfidence.GenotypeQualityValue + "'," +
                        "'" + assaySnvConfidence.ReadDepthDDL + "'," +
                        "'" + assaySnvConfidence.ReadDepthValue + "'," +
                        "'" + assaySnvConfidence.AltPercentageDDL + "'," +
                        "'" + assaySnvConfidence.AltPercentageValue + "'," +
                        "'" + assaySnvConfidence.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


    }
}
