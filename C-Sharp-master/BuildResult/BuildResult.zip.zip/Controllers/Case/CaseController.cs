﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Case;
using ODIN2_Modules;
using ODIN2_Modules.Case;

namespace ODIN2_API.Controllers.Case
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class CaseController : ControllerBase
    {
        private readonly ICaseService _caseService;

        public CaseController(ICaseService caseService)
        {

            _caseService = caseService;

        }

        [HttpGet]
        [Route("GetAllActiveClient")]
        [ActionName("GetAllActiveClient"), Authorize]
        public async Task<ActionResult> GetAllActiveClient()
        {
            var driver = await _caseService.GetAllActiveClient();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            try
            {
                if (driver == null)
                {
                    var returnMsg = string.Format("All Active Client data");
                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = returnMsg;
                    return Ok(responseDetails);
                }

                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = "Data fetched successfully";
                responseDetails.ResponseData = driver;
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }

        }
        [HttpGet]
        [Route("GetAllAnalysisType")]
        [ActionName("GetAllAnalysisType"), Authorize]
        public async Task<ActionResult> GetAllAnalysisType()
        {
            var driver = await _caseService.GetAllAnalysisType();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            try
            {
                if (driver == null)
                {
                    var returnMsg = string.Format("All Analysis Type Data");

                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = returnMsg;
                    return Ok(responseDetails);
                }

                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = "Data fetched successfully";
                responseDetails.ResponseData = driver;
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }
        }

        [HttpGet]
        [Route("GetAllAssay")]
        [ActionName("GetAllAssay"), Authorize]
        public async Task<ActionResult> GetAllAssay()
        {
            var driver = await _caseService.GetAllAssay();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            try
            {
                if (driver == null)
                {
                    var returnMsg = string.Format("All Assay Data");

                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = returnMsg;
                    return Ok(responseDetails);
                }

                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = "Data fetched successfully";
                responseDetails.ResponseData = driver;
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }

        }

        /// <summary>
        /// gets the statuscode from AddCaseDetails method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="AddCaseDetails"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddCaseDetails")]
        [ActionName("AddCaseDetails"), Authorize]
        public async Task<ActionResult> AddCaseDetails([FromBody] CaseDetails caseDetails)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            var driver = await _caseService.AddCaseDetails(caseDetails);
            try
            {
                if (driver[0].StatusCode.ToString() == "404")
                {
                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                else
                {
                    responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                    responseDetails.ResponseData = driver[0].ResponseData.ToString();
                }
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }

        }

        [HttpGet]
        [Route("GetGender")]
        [ActionName("GetGender"), Authorize]
        public async Task<ActionResult> GetGender()
        {
            var driver = await _caseService.GetGender();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            try
            {
                if (driver == null)
                {
                    var returnMsg = string.Format("All Gender Data");

                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = returnMsg;
                    return Ok(responseDetails);
                }

                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = "Data fetched successfully";
                responseDetails.ResponseData = driver;
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }

        }

        [HttpGet]
        [Route("GetConsanguinity")]
        [ActionName("GetConsanguinity"), Authorize]
        public async Task<ActionResult> GetConsanguinity()
        {
            var driver = await _caseService.GetConsanguinity();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            try
            {
                if (driver == null)
                {
                    var returnMsg = string.Format("All Consanguinity Data");

                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = returnMsg;
                    return Ok(responseDetails);
                }

                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = "Data fetched successfully";
                responseDetails.ResponseData = driver;
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }

        }
        /// <summary>
        /// gets the statuscode from AddCaseProbandInformation method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="AddCaseProbandInformation"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddCaseProbandInformation")]
        [ActionName("AddCaseProbandInformation"), Authorize]
        public async Task<ActionResult> AddCaseProbandInformation([FromBody] CaseProbandInformation caseProbandInformation)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            var driver = await _caseService.AddCaseProbandInformation(caseProbandInformation);
            try
            {
                if (driver[0].StatusCode.ToString() == "404")
                {
                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                else
                {
                    responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }

        }

        /// <summary>
        /// gets the statuscode from AddCasePhenotypes method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="AddCasePhenotypes"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddCasePhenotypes")]
        [ActionName("AddCasePhenotypes"), Authorize]
        public async Task<ActionResult> AddCasePhenotypes([FromBody] CasePhenotypes casePhenotypes)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            var driver = await _caseService.AddCasePhenotypes(casePhenotypes);
            try
            {
                if (driver[0].StatusCode.ToString() == "404")
                {
                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                else
                {
                    responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }

        }

        /// <summary>
        /// gets the statuscode from AddCaseGeneList method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="AddCaseGeneList"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddCaseGeneList")]
        [ActionName("AddCaseGeneList"), Authorize]
        public async Task<ActionResult> AddCaseGeneList([FromBody] CaseGeneList caseGeneList)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            var driver = await _caseService.AddCaseGeneList(caseGeneList);
            try
            {
                if (driver[0].StatusCode.ToString() == "404")
                {
                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                else
                {
                    responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }
        }

        /// <summary>
        /// gets the statuscode from AddCaseFamilyTree method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="AddCaseFamilyTree"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddCaseFamilyTree")]
        [ActionName("AddCaseFamilyTree"), Authorize]
        public async Task<ActionResult> AddCaseFamilyTree([FromBody] CaseFamilyTree caseFamilyTree)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            var driver = await _caseService.AddCaseFamilyTree(caseFamilyTree);
            try
            {
                if (driver[0].StatusCode.ToString() == "404")
                {
                    responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                else
                {
                    responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                    responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                }
                return Ok(responseDetails);
            }
            catch (Exception ex)
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = ex.Message;
                return Ok(responseDetails);
            }
        }

        [HttpGet]
        [Route("GetCaseDetailsByStatusId/{statusId}")]
        [ActionName("GetCaseDetailsByStatusId"), Authorize]
        public async Task<ActionResult> GetCaseDetailsByStatusId(int statusId)
        {
            var driver = await _caseService.GetCaseDetailsByStatusId(statusId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Case Details By Status Id");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetCaseSectionsDataByCaseId/{caseId}")]
        [ActionName("GetCaseSectionsDataByCaseId"), Authorize]
        public async Task<ActionResult> GetCaseSectionsDataByCaseId(int caseId)
        {
            var driver = await _caseService.GetCaseSectionsDataByCaseId(caseId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Case Sections Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetCaseDetailsByCaseId/{caseId}")]
        [ActionName("GetCaseDetailsByCaseId"), Authorize]
        public async Task<ActionResult> GetCaseDetailsByCaseId(int caseId)
        {
            var driver = await _caseService.GetCaseDetailsByCaseId(caseId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Case Details By CaseId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetCaseProbandInformationByCaseId/{caseId}")]
        [ActionName("GetCaseProbandInformationByCaseId"), Authorize]
        public async Task<ActionResult> GetCaseProbandInformationByCaseId(int caseId)
        {
            var driver = await _caseService.GetCaseProbandInformationByCaseId(caseId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Case Proband Information By CaseId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetCasePhenotypesByCaseId/{caseId}")]
        [ActionName("GetCasePhenotypesByCaseId"), Authorize]
        public async Task<ActionResult> GetCasePhenotypesByCaseId(int caseId)
        {
            var driver = await _caseService.GetCasePhenotypesByCaseId(caseId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Case Phenotypes By CaseId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetCaseGeneListByCaseId/{caseId}")]
        [ActionName("GetCaseGeneListByCaseId"), Authorize]
        public async Task<ActionResult> GetCaseGeneListByCaseId(int caseId)
        {
            var driver = await _caseService.GetCaseGeneListByCaseId(caseId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Case GeneList By CaseId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetCaseFamilyTreeByCaseId/{caseId}")]
        [ActionName("GetCaseFamilyTreeByCaseId"), Authorize]
        public async Task<ActionResult> GetCaseFamilyTreeByCaseId(int caseId)
        {
            var driver = await _caseService.GetCaseFamilyTreeByCaseId(caseId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Case Family Tree By CaseId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateCaseNotes")]
        [ActionName("UpdateCaseNotes"), Authorize]
        public async Task<ActionResult> UpdateCaseNotes([FromBody] CaseDetails caseDetails)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _caseService.UpdateCaseNotes(caseDetails);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }


    }
}
