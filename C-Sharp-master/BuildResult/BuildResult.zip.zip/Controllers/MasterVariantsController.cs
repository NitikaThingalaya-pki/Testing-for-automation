﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Services;
using ODIN2_Modules;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ODIN2_Main.Controllers

{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class MasterVariantsController : ControllerBase
    {
        private readonly IESMasterVariantsService _masterVariantsService;

        public MasterVariantsController(IESMasterVariantsService masterVariantsService)
        {
            _masterVariantsService = masterVariantsService;
        }


        /// <summary>
        /// fetch data from MasterVariants table by geneid
        /// </summary>
        /// <param name="geneId"></param>
        /// <returns>MasterVariants data by geneid</returns>
        // GET api/<MasterVariantsController>/5
        [HttpGet("{geneId}")]
        [ActionName("GetDataByGeneId"), Authorize]
        public async Task<IList<MasterVariants>> GetMasterGenesDataByGeneId(string geneId)
        {
            var results = await _masterVariantsService.GetDataByGeneId(geneId);
            return results;
        }


        [HttpGet(Name = "GetAllVariant"), Authorize]
        public async Task<ActionResult> GetAllVariant()
        {
            var driver = await _masterVariantsService.GetAllVariant();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All GetAllVariant");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }


    }
}
