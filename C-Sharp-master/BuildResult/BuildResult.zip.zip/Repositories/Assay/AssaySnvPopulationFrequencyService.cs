﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssaySnvPopulationFrequencyService : BaseAsyncRepository, IAssaySnvPopulationFrequencyService
    {
        public AssaySnvPopulationFrequencyService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssaySnvPopulationFrequency
        /// </summary>
        /// <param name="addAssaySnvPopulationFrequency"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssaySnvPopulationFrequency(AssaySnvPopulationFrequency assaySnvPopulationFrequency)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssaySnvPopulationFrequency(
                                    '" + assaySnvPopulationFrequency.AssayId + "'," +
                                    "'" + assaySnvPopulationFrequency.TabId + "'," +
                                    "'" + assaySnvPopulationFrequency.gnomADDDL + "'," +
                                    "'" + assaySnvPopulationFrequency.gnomADValue + "'," +
                                    "'" + assaySnvPopulationFrequency.ESP6500DDL + "'," +
                                    "'" + assaySnvPopulationFrequency.ESP6500Value + "'," +
                                    "'" + assaySnvPopulationFrequency.GMEDDL + "'," +
                                    "'" + assaySnvPopulationFrequency.GMEValue + "'," +
                                    "'" + assaySnvPopulationFrequency.ODINDDL + "'," +
                                    "'" + assaySnvPopulationFrequency.ODINValue + "'," +
                                    "'" + assaySnvPopulationFrequency.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="getassaySnvPopulationFrequencybyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<AssaySnvPopulationFrequency> GetAssaySnvPopulationFrequencyById(int tabId, int assayId)
        {
            AssaySnvPopulationFrequency drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select AssaySNVPopulationFrequencyId,AssayId,TabId,
                                        gnomADDDL,gnomADValue,ESP6500DDL,ESP6500Value,
                                        GMEDDL,GMEValue,ODINDDL,ODINValue,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_SNV_PopulationFrequency 
                                        where 
                                        tabId =" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<AssaySnvPopulationFrequency>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssaySnvPopulationFrequency
        /// </summary>
        /// <param name="UpdateAssaySnvPopulationFrequency"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssaySnvPopulationFrequency(AssaySnvPopulationFrequency assaySnvPopulationFrequency)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssaySNVPopulationFrequency(
                                    '" + assaySnvPopulationFrequency.AssayId + "'," +
                                    "'" + assaySnvPopulationFrequency.TabId + "'," +
                                    "'" + assaySnvPopulationFrequency.gnomADDDL + "'," +
                                    "'" + assaySnvPopulationFrequency.gnomADValue + "'," +
                                    "'" + assaySnvPopulationFrequency.ESP6500DDL + "'," +
                                    "'" + assaySnvPopulationFrequency.ESP6500Value + "'," +
                                    "'" + assaySnvPopulationFrequency.GMEDDL + "'," +
                                    "'" + assaySnvPopulationFrequency.GMEValue + "'," +
                                    "'" + assaySnvPopulationFrequency.ODINDDL + "'," +
                                    "'" + assaySnvPopulationFrequency.ODINValue + "'," +
                                    "'" + assaySnvPopulationFrequency.UpdatedBy + "');";

                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


    }
}
