﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class TabService : BaseAsyncRepository, ITabService
    {
        public TabService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the tab master
        /// </summary>
        /// <param name="addtab"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddTab(MasterTab tab)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertTab('" + tab.TabName + "','" + tab.AssayId + "','" + tab.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To update the tab master
        /// </summary>
        /// <param name="updatetab"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateTab(MasterTab tab)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spUpdateTab('" + tab.TabId + "','" + tab.TabName + "','" + tab.AssayId + "','" + tab.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
                             
        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="gettabbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<MasterTab> GetTabById(int tabId, int assayId)
        {
            MasterTab drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select tabid,tabname,assayid,createdby,createddate,updatedby,updateddate  from assay_tab_master  where tabId=" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<MasterTab>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

    }
}
