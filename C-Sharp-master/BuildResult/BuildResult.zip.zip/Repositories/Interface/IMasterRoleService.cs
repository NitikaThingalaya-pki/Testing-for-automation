﻿using ODIN2_Modules;

namespace ODIN2_API.Repositories.Interface
{
    public interface IMasterRoleService
    {
        Task<List<MasterRoles>> GetAllRoles();
    }
}
