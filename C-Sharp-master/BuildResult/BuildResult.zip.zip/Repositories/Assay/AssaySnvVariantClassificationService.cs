﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssaySnvVariantClassificationService : BaseAsyncRepository, IAssaySnvVariantClassificationService
    {
        public AssaySnvVariantClassificationService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssaySnvVariantClassification
        /// </summary>
        /// <param name="addAssaySnvVariantClassification"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssaySnvVariantClassification(AssaySnvVariantClassification assaySnvVariantClassification)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssaySnvVariantClassification(
                                    '" + assaySnvVariantClassification.AssayId + "'," +
                                    "'" + assaySnvVariantClassification.TabId + "'," +
                                    "'" + assaySnvVariantClassification.HGMDMSDDL + "'," +
                                    "'" + assaySnvVariantClassification.ClinVarMSDDL + "'," +
                                    "'" + assaySnvVariantClassification.ODINMSDDL + "'," +
                                    "'" + assaySnvVariantClassification.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="getassaySnvVariantClassificationbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<AssaySnvVariantClassification> GetAssaySnvVariantClassificationById(int tabId, int assayId)
        {
            AssaySnvVariantClassification drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select AssaySNVVariantClassificationId,AssayId,TabId,
                                    HGMDMSDDL,ClinVarMSDDL,ODINMSDDL,
                                    CreatedBy,Createddate,UpdatedBy,Updateddate 
                                    from Assay_SNV_VariantClassification where 
                                    tabId =" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<AssaySnvVariantClassification>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssaySnvVariantClassification
        /// </summary>
        /// <param name="UpdateAssaySnvVariantClassification"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssaySnvVariantClassification(AssaySnvVariantClassification assaySnvVariantClassification)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssaySNVVariantClassification(
                                    '" + assaySnvVariantClassification.AssayId + "'," +
                                    "'" + assaySnvVariantClassification.TabId + "'," +
                                    "'" + assaySnvVariantClassification.HGMDMSDDL + "'," +
                                    "'" + assaySnvVariantClassification.ClinVarMSDDL + "'," +
                                    "'" + assaySnvVariantClassification.ODINMSDDL + "'," +
                                    "'" + assaySnvVariantClassification.UpdatedBy + "');";

                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


    }
}
