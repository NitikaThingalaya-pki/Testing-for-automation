﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class AssayGeneGeneListController : ControllerBase
    {
        private readonly IAssayGeneGeneListService _assayGeneGeneListService;

        public AssayGeneGeneListController(IAssayGeneGeneListService assayGeneGeneListService)
        {
            _assayGeneGeneListService = assayGeneGeneListService;
        }

        /// <summary>
        /// gets the statuscode from AddAssayGeneGeneList method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssayGeneGeneList"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssayGeneGeneList")]
        [ActionName("AddAssayGeneGeneList"), Authorize]
        public async Task<ActionResult> AddAssayGeneGeneList([FromBody] AssayGeneGeneList assayGeneGeneList)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assayGeneGeneListService.AddAssayGeneGeneList(assayGeneGeneList);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            return Ok(responseDetails);

        }


        [HttpGet]
        [Route("GetAssayGeneGeneListById/{tabId}&{assayId}")]
        [ActionName("GetAssayGeneGeneListById"), Authorize]
        public async Task<ActionResult> GetAssayGeneGeneListById(int tabId, int assayId)
        {
            var driver = await _assayGeneGeneListService.GetAssayGeneGeneListById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("AssayGeneGeneList Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }


        [HttpPost]
        [Route("UpdateAssayGeneGeneList")]
        [ActionName("UpdateAssayGeneGeneList"), Authorize]
        public async Task<ActionResult> UpdateAssayGeneGeneList([FromBody] AssayGeneGeneList assayGeneGeneList)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assayGeneGeneListService.UpdateAssayGeneGeneList(assayGeneGeneList);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }

    }
}
