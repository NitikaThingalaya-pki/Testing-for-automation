﻿using ODIN2_Modules;

namespace ODIN2_API.Repositories.Interface
{
    public interface IUserRoleMappingService
    {
        Task<List<BaseResponseStatus>> AddUserRoleMapping(UserRoleMapping userrolemapping);
        Task<List<BaseResponseStatus>> UpdateUserRoleMapping(UserRoleMapping userrolemapping);
        Task<List<BaseResponseStatus>> DeleteUserRoleMappingById(UserRoleMapping userrolemapping);
        Task<List<UserRoleMapping>> GetUserRoleMappingById(int userRoleMappingId);
        Task<List<UserRoleMapping>> GetAllUserRoleMapping();
    }
}
