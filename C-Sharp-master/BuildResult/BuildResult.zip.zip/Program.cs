using ODIN2_API.Extensions;
using ODIN2_API.Repositories;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Services;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.OpenApi.Models;
using ODIN2_API.Repositories.Assay;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_API.Repositories.Comman;
using ODIN2_API.Repositories.Interface.Comman;
using ODIN2_API.Repositories.Interface.Case;
using ODIN2_API.Repositories.Case;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "ODIN API",
        Version = "v1"
    });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 1safsfsdfdfd\"",
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        {
            new OpenApiSecurityScheme {
                Reference = new OpenApiReference {
                    Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});


builder.Services.AddElasticsearch(builder.Configuration);
builder.Services.AddSingleton<IESMasterGenesService, ESMasterGenesService>();
builder.Services.AddSingleton<IESMasterVariantsService, ESMasterVariantsService>();
builder.Services.AddSingleton<ILoginAsyncRepository, LoginAsyncRepository>();
builder.Services.AddSingleton<IRegisterAsyncRepository, RegisterAsyncRepository>();
builder.Services.AddSingleton<IRoleModuleMappingService, RoleModuleMappingService>();
builder.Services.AddSingleton<IUserRoleMappingService, UserRoleMappingService>();
builder.Services.AddSingleton<IClientService, ClientService>();

builder.Services.AddSingleton<IAssayService, AssayService>();
builder.Services.AddSingleton<ITabService, TabService>();
builder.Services.AddSingleton<IAssaySnvConfidenceService, AssaySnvConfidenceService>();
builder.Services.AddSingleton<IAssaySnvVariantTypeService, AssaySnvVariantTypeService>();
builder.Services.AddSingleton<IAssaySnvVariantLocationService, AssaySnvVariantLocationService>();
builder.Services.AddSingleton<IAssaySnvVariantClassificationService, AssaySnvVariantClassificationService>();
builder.Services.AddSingleton<IAssaySnvInSilicoPredictionService, AssaySnvInSilicoPredictionService>();
builder.Services.AddSingleton<IAssaySnvPopulationFrequencyService, AssaySnvPopulationFrequencyService>();
builder.Services.AddSingleton<IAssaySnvInheritanceService, AssaySnvInheritanceService>();
builder.Services.AddSingleton<IAssayGeneGeneListService, AssayGeneGeneListService>();
builder.Services.AddSingleton<IAssayViewService, AssayViewService>();
builder.Services.AddSingleton<ICaseService, CaseService>();

builder.Services.AddSingleton<IMasterUserService, MasterUserService>();
builder.Services.AddSingleton<IMasterRoleService, MasterRoleService>();

builder.Services.AddSingleton<IGeneSymbolSearch, GeneSymbolSearchService>();
builder.Services.AddSingleton<IHPOphenotype, HPOphenotypeService>();
builder.Services.AddSingleton<Iorpha_phenotype, orpha_phenotypeService>();
builder.Services.AddSingleton<Iomim_morbidmap, omim_morbidmapservice>();

builder.Services.AddSingleton<IClinvargene, ClinvargeneService>();

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
        {
            options.SaveToken = true;
            options.RequireHttpsMetadata = false;
            options.TokenValidationParameters = new TokenValidationParameters()
            {
                ValidateIssuer = false,
                ValidateAudience = false,
                //other settings for exact time
                ClockSkew = TimeSpan.Zero,
                IssuerSigningKey = new SymmetricSecurityKey(
                    System.Text.Encoding.UTF8.GetBytes(
                        builder.Configuration.GetSection("AppSettings:Token").Value
                        ))
            };
        });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();
app.UseAuthentication();

app.UseAuthorization();


app.MapControllers();

app.Run();
