﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class AssaySnvVariantTypeController : ControllerBase
    {
        private readonly IAssaySnvVariantTypeService _assaySnvVariantTypeService;

        public AssaySnvVariantTypeController(IAssaySnvVariantTypeService assaySnvVariantTypeService)
        {
            _assaySnvVariantTypeService = assaySnvVariantTypeService;
        }

        /// <summary>
        /// gets the statuscode from AddAssaySnvVariantType method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssaySnvVariantType"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssaySnvVariantType")]
        [ActionName("AddAssaySnvVariantType"), Authorize]
        public async Task<ActionResult> AddAssaySnvVariantType([FromBody] AssaySnvVariantType assaySnvVariantType)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvVariantTypeService.AddAssaySnvVariantType(assaySnvVariantType);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }


        [HttpGet]
        [Route("GetAssaySnvVariantTypeById/{tabId}&{assayId}")]
        [ActionName("GetAssaySnvVariantTypeById"), Authorize]
        public async Task<ActionResult> GetAssaySnvVariantTypeById(int tabId, int assayId)
        {
            var driver = await _assaySnvVariantTypeService.GetAssaySnvVariantTypeById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("AssaySnvVariantType Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateAssaySnvVariantType")]
        [ActionName("UpdateAssaySnvVariantType"), Authorize]
        public async Task<ActionResult> UpdateAssaySnvVariantType([FromBody] AssaySnvVariantType assaySnvVariantType)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvVariantTypeService.UpdateAssaySnvVariantType(assaySnvVariantType);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }

    }
}
