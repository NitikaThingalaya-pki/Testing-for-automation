﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class AssayViewController : ControllerBase
    {

        private readonly IAssayViewService _AssayViewService;
        public AssayViewController(IAssayViewService AssayViewService)
        {
            _AssayViewService = AssayViewService;
        }

        /// <summary>
        /// gets the statuscode from AddAssayView method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssayView"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssayView")]
        [ActionName("AddAssayView"), Authorize]
        public async Task<ActionResult> AddAssayView([FromBody] AssayView AssayView)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _AssayViewService.AddAssayView(AssayView);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateAssayView")]
        [ActionName("UpdateAssayView"), Authorize]
        public async Task<ActionResult> UpdateAssayView([FromBody] AssayView AssayView)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _AssayViewService.UpdateAssayView(AssayView);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            return Ok(responseDetails);
        }

    }
}
