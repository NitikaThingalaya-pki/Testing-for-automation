﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssaySnvVariantLocationService : BaseAsyncRepository, IAssaySnvVariantLocationService
    {
        public AssaySnvVariantLocationService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssaySnvVariantLocation
        /// </summary>
        /// <param name="addAssaySnvVariantLocation"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssaySnvVariantLocation(AssaySnvVariantLocation assaySnvVariantLocation)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssaySnvVariantLocation(
                                    '" + assaySnvVariantLocation.AssayId + "'," +
                                    "'" + assaySnvVariantLocation.TabId + "'," +
                                    "'" + assaySnvVariantLocation.PositionStartDDL + "'," +
                                    "'" + assaySnvVariantLocation.PositionStartValue + "'," +
                                    "'" + assaySnvVariantLocation.PositionEndDDL + "'," +
                                    "'" + assaySnvVariantLocation.PositionEndValue + "'," +
                                    "'" + assaySnvVariantLocation.ChromosomeDDL + "'," +
                                    "'" + assaySnvVariantLocation.BEDFileName + "'," +
                                    "'" + assaySnvVariantLocation.BEDFilePath + "'," +
                                    "'" + assaySnvVariantLocation.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="getassaySnvVariantLocationbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<AssaySnvVariantLocation> GetAssaySnvVariantLocationById(int tabId, int assayId)
        {
            AssaySnvVariantLocation drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select AssaySNVVariantLocationId,AssayId,TabId,
                                        PositionStartDDL,PositionStartValue,PositionEndDDL,PositionEndValue,ChromosomeDDL,
                                        BEDFileName,BEDFilePath,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_SNV_VariantLocation 
                                        where 
                                        tabId =" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<AssaySnvVariantLocation>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssaySnvVariantLocation
        /// </summary>
        /// <param name="UpdateAssaySnvVariantLocation"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssaySnvVariantLocation(AssaySnvVariantLocation assaySnvVariantLocation)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssaySNVVariantLocation(
                                    '" + assaySnvVariantLocation.AssayId + "'," +
                                    "'" + assaySnvVariantLocation.TabId + "'," +
                                    "'" + assaySnvVariantLocation.PositionStartDDL + "'," +
                                    "'" + assaySnvVariantLocation.PositionStartValue + "'," +
                                    "'" + assaySnvVariantLocation.PositionEndDDL + "'," +
                                    "'" + assaySnvVariantLocation.PositionEndValue + "'," +
                                    "'" + assaySnvVariantLocation.ChromosomeDDL + "'," +
                                    "'" + assaySnvVariantLocation.BEDFileName + "'," +
                                    "'" + assaySnvVariantLocation.BEDFilePath + "'," +
                                    "'" + assaySnvVariantLocation.UpdatedBy + "');";

                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


    }
}
