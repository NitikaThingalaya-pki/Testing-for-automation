﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Repositories
{
    public class RegisterAsyncRepository : BaseAsyncRepository, IRegisterAsyncRepository
    {
        public RegisterAsyncRepository(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To registere the user 
        /// </summary>
        /// <param name="register"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> RegisterUser(MasterUser register)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
           
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spregisteruser('" + register.UserName + "','" + register.Password + "','" + register.FirstName + "','" + register.MiddleName + "','" + register.LastName + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }
            
            return drivers;
        }
    }
}
