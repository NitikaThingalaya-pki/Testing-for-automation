﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class AssaySnvVariantLocationController : ControllerBase
    {
        private readonly IAssaySnvVariantLocationService _assaySnvVariantLocationService;

        public AssaySnvVariantLocationController(IAssaySnvVariantLocationService assaySnvVariantLocationService)
        {
            _assaySnvVariantLocationService = assaySnvVariantLocationService;
        }

        /// <summary>
        /// gets the statuscode from AddAssaySnvVariantLocation method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssaySnvVariantLocation"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssaySnvVariantLocation")]
        [ActionName("AddAssaySnvVariantLocation"), Authorize]
        public async Task<ActionResult> AddAssaySnvVariantLocation([FromBody] AssaySnvVariantLocation assaySnvVariantLocation)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvVariantLocationService.AddAssaySnvVariantLocation(assaySnvVariantLocation);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            return Ok(responseDetails);

        }


        [HttpGet]
        [Route("GetAssaySnvVariantLocationById/{tabId}&{assayId}")]
        [ActionName("GetAssaySnvVariantLocationById"), Authorize]
        public async Task<ActionResult> GetAssaySnvVariantLocationById(int tabId, int assayId)
        {
            var driver = await _assaySnvVariantLocationService.GetAssaySnvVariantLocationById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("AssaySnvVariantLocation Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateAssaySnvVariantLocation")]
        [ActionName("UpdateAssaySnvVariantLocation"), Authorize]
        public async Task<ActionResult> UpdateAssaySnvVariantLocation([FromBody] AssaySnvVariantLocation assaySnvVariantLocation)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvVariantLocationService.UpdateAssaySnvVariantLocation(assaySnvVariantLocation);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }

    }
}
