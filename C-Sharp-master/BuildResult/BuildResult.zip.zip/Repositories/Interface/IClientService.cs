﻿using ODIN2_Modules;

namespace ODIN2_API.Repositories.Interface
{
    public interface IClientService
    {
        Task<List<BaseResponseStatus>> AddClient(MasterClient client);
        Task<List<BaseResponseStatus>> UpdateClient(MasterClient client);
        Task<List<BaseResponseStatus>> DeleteClientById(MasterClient client);
        Task<List<BaseResponseStatus>> ActivateClientById(MasterClient client);
        Task<List<BaseResponseStatus>> DeactivateClientById(MasterClient client);
        Task<MasterClient> GetClientById(int clientId);
        Task<List<MasterClient>> GetAllClient();
        Task<List<MasterClient>> GetAllActiveClient();
    }
}
