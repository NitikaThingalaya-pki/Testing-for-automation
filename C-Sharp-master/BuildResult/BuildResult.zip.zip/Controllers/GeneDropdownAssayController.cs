﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface.Comman;
using ODIN2_Modules;
using Microsoft.AspNetCore.Authorization;

namespace ODIN2_API.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class GeneDropdownAssayController : ControllerBase
    {
        private readonly IHPOphenotype _geneSymbolSearch;
        private readonly Iorpha_phenotype _orpha_phenotype;
        private readonly Iomim_morbidmap _omim_morbidmap;
        private readonly IClinvargene _Clinvargene;

        public GeneDropdownAssayController(IHPOphenotype geneSymbolSearch, Iorpha_phenotype orpha_phenotype, Iomim_morbidmap omim_morbidmap, IClinvargene Clinvargene)
        {

            _geneSymbolSearch = geneSymbolSearch;
            _orpha_phenotype = orpha_phenotype;
            _omim_morbidmap = omim_morbidmap;
            _Clinvargene = Clinvargene;
        }


        [HttpGet]
        [Route("GetAllHPOPhenotype/{SearchGeneSymbol}")]
        [ActionName("GetAllHPOPhenotype")]
        public async Task<ActionResult> GetAllHPOPhenotype(string SearchGeneSymbol)
        {
            var driver = await _geneSymbolSearch.GetAllHPOPhenotype(SearchGeneSymbol);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All GeneSymbolSearchResult");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetAllHPOPhenotypeList")]
        [ActionName("GetAllHPOPhenotypeList")]
        public async Task<ActionResult> GetAllHPOPhenotypeList()
        {
            var driver = await _geneSymbolSearch.GetAllHPOPhenotypeList();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All GeneSymbolSearchResult");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }


        [HttpGet]
        [Route("GetAllorphanetPhenotype/{SearchGeneSymbol}")]
        [ActionName("GetAllorphanetPhenotype")]
        public async Task<ActionResult> GetAllorphanetPhenotype(string SearchGeneSymbol)
        {
            var driver = await _orpha_phenotype.GetAllorphanetPhenotype(SearchGeneSymbol);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All GetAllorphanetPhenotype");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }


        [HttpGet]
        [Route("GetAllOmimmordimapPhenotype/{SearchGeneSymbol}")]
        [ActionName("GetAllOmimmordimapPhenotype")]
        public async Task<ActionResult> GetAllOmimmordimapPhenotype(string SearchGeneSymbol)
        {
            var driver = await _omim_morbidmap.GetAllOmimmordimapPhenotype(SearchGeneSymbol);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All GetAllorphanetPhenotype");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }


        [HttpGet]
        [Route("GetAllClinvargenePhenotype/{SearchGeneSymbol}")]
        [ActionName("GetAllClinvargenePhenotype")]
        public async Task<ActionResult> GetAllClinvargenePhenotype(string SearchGeneSymbol)
        {
            var driver = await _Clinvargene.GetAllClinvargenePhenotype(SearchGeneSymbol);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All GetAllorphanetPhenotype");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }
    }
}
