﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Services;
using ODIN2_Modules;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860
namespace ODIN2_Main.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class MasterGenesController : ControllerBase
    {
        private readonly IESMasterGenesService _masterGenesService;

        public MasterGenesController(IESMasterGenesService masterGenesService)
        {
            _masterGenesService = masterGenesService;
        }

        
        /// <summary>
        /// fetch data from Mastergene table by geneid
        /// </summary>
        /// <param name="geneId"></param>
        /// <returns>mastergenes data by geneid</returns>
        // GET api/<MasterGenesController>/5
        [HttpGet("{geneId}")]
        [ActionName("GetDataByGeneId"), Authorize]
        public async Task<IList<MasterGenes>> GetMasterGenesDataByGeneId(string geneId)
        {
            var results = await _masterGenesService.GetDataByGeneId(geneId);
            return results;
        }

        [HttpGet(Name = "GetAllDataGene")]
        public async Task<ActionResult> GetAllDataGene()
        {
            var driver = await _masterGenesService.GetAllDataGene();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All GetAllDataGene");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }
    }
}
