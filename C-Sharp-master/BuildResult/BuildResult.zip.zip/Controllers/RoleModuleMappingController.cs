﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class RoleModuleMappingController : ControllerBase
    {

        private readonly IRoleModuleMappingService _roleModuleMappingService;

        public RoleModuleMappingController(IRoleModuleMappingService roleModuleMappingService)
        {

            _roleModuleMappingService = roleModuleMappingService;

        }



        [HttpPost]
        [Route("AddRole")]
        [ActionName("AddRole"), Authorize]
        public async Task<ActionResult> AddRole([FromBody] RoleModuleMapping roleModuleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _roleModuleMappingService.AddRole(roleModuleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("UpdateRole")]
        [ActionName("UpdateRole"), Authorize]
        public async Task<ActionResult> UpdateRole([FromBody] RoleModuleMapping roleModuleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _roleModuleMappingService.UpdateRole(roleModuleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }


        [HttpPost]
        [Route("DeleteRole")]
        [ActionName("DeleteRole"), Authorize]
        public async Task<ActionResult> DeleteRole([FromBody] RoleModuleMapping roleModuleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _roleModuleMappingService.DeleteRole(roleModuleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }






        /// <summary>
        /// gets the statuscode from AddRoleModuleMapping method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addrolemodulemapping"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddRoleModuleMapping")]
        [ActionName("AddRoleModuleMapping"), Authorize]
        public async Task<ActionResult> AddRoleModuleMapping([FromBody] RoleModuleMapping roleModuleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _roleModuleMappingService.AddRoleModuleMapping(roleModuleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("UpdateRoleModuleMapping")]
        [ActionName("UpdateRoleModuleMapping"), Authorize]
        public async Task<ActionResult> UpdateRoleModuleMapping([FromBody] RoleModuleMapping roleModuleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _roleModuleMappingService.UpdateRoleModuleMapping(roleModuleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }


        [HttpPost]
        [Route("DeleteRoleModuleMappingById")]
        [ActionName("DeleteRoleModuleMappingById"), Authorize]
        public async Task<ActionResult> DeleteRoleModuleMappingById([FromBody] RoleModuleMapping roleModuleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _roleModuleMappingService.DeleteRoleModuleMappingById(roleModuleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetRoleModuleMappingById/{roleModuleMappingId}")]
        [ActionName("GetRoleModuleMappingById"), Authorize]
        public async Task<ActionResult> GetRoleModuleMappingById(int roleModuleMappingId)
        {
            
            //return await _roleModuleMappingService.GetRoleModuleMappingById(roleModuleMapping);


            var driver =  await _roleModuleMappingService.GetRoleModuleMappingById(roleModuleMappingId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Role Module Mapping Data By Id");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        
        [HttpGet]
        [Route("GetRoleModuleMappingList")]
        [ActionName("GetRoleModuleMappingList"), Authorize]
        public async Task<ActionResult> GetRoleModuleMappingList()
        {

            var driver = await _roleModuleMappingService.GetRoleModuleMappingList();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Role Module Mapping Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetAllRoleModuleMapping")]
        [ActionName("GetAllRoleModuleMapping"), Authorize]
        public async Task<ActionResult> GetAllRoleModuleMapping()
        {
            
            var driver = await _roleModuleMappingService.GetAllRoleModuleMapping();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Role Module Mapping Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetMenuPermission")]
        [ActionName("GetMenuPermission"), Authorize]
        public async Task<ActionResult> GetMenuPermission()
        {

            var driver = await _roleModuleMappingService.GetMenuPermission();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Role Module Mapping Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }


    }
}
