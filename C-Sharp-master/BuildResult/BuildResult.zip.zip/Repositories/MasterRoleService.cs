﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Repositories
{
    public class MasterRoleService : BaseAsyncRepository, IMasterRoleService
    {
        public MasterRoleService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To get the roles 
        /// </summary>
        /// <param name="getallroles"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<MasterRoles>> GetAllRoles()
        {
            List<MasterRoles> drivers = new List<MasterRoles>();
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select roleid,role,isactive  from master_roles where IsActive=true;";
                 
                    var driverList = await dbConnection.QueryAsync<MasterRoles>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
    }
}
