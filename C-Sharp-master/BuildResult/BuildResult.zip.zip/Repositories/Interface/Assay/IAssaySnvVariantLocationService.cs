﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface IAssaySnvVariantLocationService
    {
        Task<List<BaseResponseStatus>> AddAssaySnvVariantLocation(AssaySnvVariantLocation assaySnvVariantLocation);
        Task<AssaySnvVariantLocation> GetAssaySnvVariantLocationById(int tabId, int assayId);
        Task<List<BaseResponseStatus>> UpdateAssaySnvVariantLocation(AssaySnvVariantLocation assaySnvVariantLocation);
    }
}
