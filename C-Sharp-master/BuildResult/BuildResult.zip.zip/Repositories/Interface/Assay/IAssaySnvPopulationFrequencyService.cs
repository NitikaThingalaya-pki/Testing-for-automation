﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface IAssaySnvPopulationFrequencyService
    {
        Task<List<BaseResponseStatus>> AddAssaySnvPopulationFrequency(AssaySnvPopulationFrequency assaySnvPopulationFrequency);
        Task<AssaySnvPopulationFrequency> GetAssaySnvPopulationFrequencyById(int tabId, int assayId);
        Task<List<BaseResponseStatus>> UpdateAssaySnvPopulationFrequency(AssaySnvPopulationFrequency assaySnvPopulationFrequency);
    }
}
