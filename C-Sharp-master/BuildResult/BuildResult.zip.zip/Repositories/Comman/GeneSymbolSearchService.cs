﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Comman;
using ODIN2_Modules;
using ODIN2_Modules.Comman;


namespace ODIN2_API.Repositories.Comman
{
    public class GeneSymbolSearchService : BaseAsyncRepository, IGeneSymbolSearch
    {
        public GeneSymbolSearchService(IConfiguration configuration) : base(configuration)
        {
        }
        /// <summary>
        /// To get the assay master data 
        /// </summary>
        /// <param name="getallassay"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<GeneSymbolSearch>> GeneSymbolSearchResult(string SearchGeneSymbol)
        {
            List<GeneSymbolSearch> drivers =null;
            GeneSymbolSearch objGeneSymbolSearch = new GeneSymbolSearch();
            var querySQL = "";
           
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@SearchGeneSymbol", SearchGeneSymbol);
                    /* 1
                    	If symbol matches hgnc_symbol (hgnc_gene_info) then display hgnc_symbol (hgnc_gene_info) 
                    on the UI and use the corresponding hgnc_id (hgnc_gene_info) and gene_id (hgnc_gene_info) to move around in the DB.
                     */
                    querySQL = @"select top 1 ""hgnc id"" as Geneid, ""approved symbol"" as GeneSymbol ,'Case Hgnc symbol match' as CaseMatched   
                                    from public.public_hgnc where upper(""approved symbol"") = upper(@SearchGeneSymbol)";
                    var driverListcase1 = await dbConnection.QueryAsync<GeneSymbolSearch>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverListcase1.ToList();
                    
                    if(drivers.Count == 0)
                    {
                        /*2
                        	If symbol does not match hgnc_symbol (hgnc_gene_info) but matches prev_symbol (hgnc_prevsyms) only once,
                        then take corresponding hgnc_id (hgnc_prevsyms) and use it to extract and display hgnc_symbol 
                        (hgnc_gene_info) on the UI and use hgnc_id (hgnc_gene_info) and gene_id (hgnc_gene_info) to move around in the DB.
                         */

                        /*4
                         4.	If symbol does not match hgnc_symbol (hgnc_gene_info) but matches prev_symbol (hgnc_prevsyms) more than once, then take all corresponding hgnc_id (hgnc_prevsyms) and use it to extract and prompt user to select one
                        hgnc_symbol (hgnc_gene_info) on the UI and the one they select, 
                        use corresponding hgnc_id (hgnc_gene_info) and gene_id (hgnc_gene_info) to move around in the DB.
                         */

                        querySQL = @"select top 10 t1.""hgnc id"" as Geneid, t1.""approved symbol"" as GeneSymbol ,t1.""previous symbols"" as oldGeneSymbol ,'Case  previous symbols match' as CaseMatched  
                             from public_hgnc t1
                            where exists(select 1 from public_hgnc t2 where ',' || REGEXP_REPLACE(upper(t1.""previous symbols""), ' ', '') || ',' like '%,' || upper(@SearchGeneSymbol) || ',%');";
                        var driverListcase2 = await dbConnection.QueryAsync<GeneSymbolSearch>(querySQL, param, commandType: CommandType.Text);
                        drivers = driverListcase2.ToList();


                    }
                    if (drivers.Count == 0)
                    {
                        /* 3
                    	If symbol does not match hgnc_symbol (hgnc_gene_info) but matches alias_symbol 
                        (hgnc_aliassyms) only once, then take corresponding hgnc_id (hgnc_aliassyms) and
                        use it to extract and display hgnc_symbol (hgnc_gene_info) on the UI and use hgnc_id 
                        (hgnc_gene_info) and gene_id (hgnc_gene_info) to move around in the DB.
                                */

                        /*
                         
                          5.If symbol does not match hgnc_symbol (hgnc_gene_info)
                        but matches alias_symbol (hgnc_aliassyms) more than once, then take all corresponding hgnc_id (hgnc_aliassyms)
                        and use it to extract and prompt user to select one hgnc_symbol (hgnc_gene_info) on the UI and the one they select,
                        use corresponding hgnc_id (hgnc_gene_info) and gene_id (hgnc_gene_info) to move around in the DB.

                         */
                        querySQL =
                            @"select top 10 t1.""hgnc id"" as Geneid, t1.""approved symbol"" as GeneSymbol ,t1.""alias symbols"" as oldGeneSymbol ,'Case alias symbols match' as CaseMatched  
                             from public_hgnc t1
                            where exists(select 1 from public_hgnc t2 where ',' || REGEXP_REPLACE(upper(t1.""alias symbols""), ' ', '') || ',' like '%,' || upper(@SearchGeneSymbol) || ',%');";
                        var driverListcase3 = await dbConnection.QueryAsync<GeneSymbolSearch>(querySQL, param, commandType: CommandType.Text);
                        drivers = driverListcase3.ToList();

                    }
                    if (drivers.Count == 0)
                    {
                        /* 6
                    
                       If symbol does not match hgnc_symbol (hgnc_gene_info),
                        prev_symbol (hgnc_prevsyms) or alias_symbol (hgnc_aliassyms) 
                        but matches ncbi_symbol (ncbi_gene_info) then display ncbi_symbol (ncbi_gene_info) on the UI and
                        use the corresponding gene_id (ncbi_gene_info) to move around in the DB.


                         */
                        querySQL =
                            @"select top 1 ""geneid"" as Geneid, ""symbol"" as GeneSymbol ,'Case ncbisymbol match' as CaseMatched  
                            from public_ncbigene where upper(symbol) = upper(@SearchGeneSymbol)";
                        var driverListcase4 = await dbConnection.QueryAsync<GeneSymbolSearch>(querySQL, param, commandType: CommandType.Text);
                        drivers = driverListcase4.ToList();

                    }

                    if (drivers.Count == 0)
                    {
                        /* 
                    
                     7.	If symbol does not match hgnc_symbol (hgnc_gene_info), prev_symbol (hgnc_prevsyms),
                        alias_symbol (hgnc_aliassyms) or ncbi_symbol (ncbi_gene_info) but matches synonym (ncbi_synonyms) only once, 
                        then take corresponding gene_id (ncbi_synonyms) and use it to extract and display ncbi_symbol (ncbi_gene_info) on 
                        the UI and use gene_id (ncbi_gene_info) to move around in the DB.

                     8.	If symbol does not match hgnc_symbol (hgnc_gene_info), prev_symbol (hgnc_prevsyms), alias_symbol 
                        (hgnc_aliassyms) or ncbi_symbol (ncbi_gene_info) but matches synonym (ncbi_synonyms) more than once,
                        then take all corresponding gene_id (ncbi_synonyms) and use it to extract and prompt user to select one ncbi_symbol 
                        (ncbi_gene_info) on the UI and the one they select, use corresponding gene_id (ncbi_gene_info) to move around in the DB



                         */
                        querySQL =
                           @"select  top 10 t1.""geneid"" as Geneid, t1.""symbol"" as GeneSymbol ,t1.""synonyms"" as oldGeneSymbol ,'Case ncbi_synonyms symbols match' as CaseMatched 
                                from  public_ncbigene t1
                                where exists (select 1 from public_ncbigene t2 where '|' || REGEXP_REPLACE(upper(t1.""synonyms""),' ','') || '|' like '%|' || upper(@SearchGeneSymbol) || '|%')";
                        var driverListcase5 = await dbConnection.QueryAsync<GeneSymbolSearch>(querySQL, param, commandType: CommandType.Text);
                        drivers = driverListcase5.ToList();

                    }



                }
            }
            catch (Exception e)
            {
            }
            if (drivers.Count== 0)
            {
                objGeneSymbolSearch.GeneSymbol = "NA";
                objGeneSymbolSearch.Geneid = "0";
                objGeneSymbolSearch.CaseMatched = "Case No Data found Match";
                drivers.Add(objGeneSymbolSearch);
            }
           
            return drivers;
        }
    }
}
