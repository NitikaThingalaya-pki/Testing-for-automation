﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class AssaySnvVariantClassificationController : ControllerBase
    {
        private readonly IAssaySnvVariantClassificationService _assaySnvVariantClassificationService;

        public AssaySnvVariantClassificationController(IAssaySnvVariantClassificationService assaySnvVariantClassificationService)
        {
            _assaySnvVariantClassificationService = assaySnvVariantClassificationService;
        }

        /// <summary>
        /// gets the statuscode from AddAssaySnvVariantClassification method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssaySnvVariantClassification"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssaySnvVariantClassification")]
        [ActionName("AddAssaySnvVariantClassification"), Authorize]
        public async Task<ActionResult> AddAssaySnvVariantClassification([FromBody] AssaySnvVariantClassification assaySnvVariantClassification)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvVariantClassificationService.AddAssaySnvVariantClassification(assaySnvVariantClassification);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }


        [HttpGet]
        [Route("GetAssaySnvVariantClassificationById/{tabId}&{assayId}")]
        [ActionName("GetAssaySnvVariantClassificationById"), Authorize]
        public async Task<ActionResult> GetAssaySnvVariantClassificationById(int tabId, int assayId)
        {
            var driver = await _assaySnvVariantClassificationService.GetAssaySnvVariantClassificationById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("AssaySnvVariantClassification Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateAssaySnvVariantClassification")]
        [ActionName("UpdateAssaySnvVariantClassification"), Authorize]
        public async Task<ActionResult> UpdateAssaySnvVariantClassification([FromBody] AssaySnvVariantClassification assaySnvVariantClassification)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvVariantClassificationService.UpdateAssaySnvVariantClassification(assaySnvVariantClassification);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }

    }
}
