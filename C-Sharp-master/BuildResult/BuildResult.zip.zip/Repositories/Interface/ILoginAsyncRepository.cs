﻿using ODIN2_Modules;

namespace ODIN2_API.Repositories.Interface
{
    public interface ILoginAsyncRepository
    {
        Task<List<BaseResponseStatus>> AuthenticateUser(Login login);
    }
}
