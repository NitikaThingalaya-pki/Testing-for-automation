﻿using Dapper;
using ODIN2_API.Repositories.Interface.Comman;
using ODIN2_Modules.Comman;
using System.Data;
using System.Data.Common;

namespace ODIN2_API.Repositories.Comman
{
    public class HPOphenotypeService : BaseAsyncRepository, IHPOphenotype
    {
        public HPOphenotypeService(IConfiguration configuration) : base(configuration)
        {
        }
        /// <summary>
        /// To get the assay master data 
        /// </summary>
        /// <param name="getallassay"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<HPOphenotype>> GetAllHPOPhenotype(string SearchGeneSymbol)
        {
            List<HPOphenotype> drivers = null;
            HPOphenotype objGeneSymbolSearch = new HPOphenotype();
            var querySQL = "";

            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    string term = "%" + SearchGeneSymbol + "%";
                    param.Add("@searchHPO", term);
                    /* 1
                    	If symbol matches hgnc_symbol (hgnc_gene_info) then display hgnc_symbol (hgnc_gene_info) 
                    on the UI and use the corresponding hgnc_id (hgnc_gene_info) and gene_id (hgnc_gene_info) to move around in the DB.
                     */
                    //querySQL = @"select top 10 hpoid + ' ' + hpolabel as hpolabel ,hpoid from public.public_hpo_phenotype where  hpoid + ' ' + hpolabel like @searchHPO";
                    querySQL = @"select top 10 hpoid + ' ' + hpolabel as hpolabel ,hpoid from public.public_hpo_phenotype where  hpoid + ' ' + hpolabel like @searchHPO";
                    var driverListcase1 = await dbConnection.QueryAsync<HPOphenotype>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverListcase1.ToList();

                   



                }
            }
            catch (Exception e)
            {
            }
           

            return drivers;
        }

        public async Task<List<HPOphenotype>> GetAllHPOPhenotypeList()
        {
            List<HPOphenotype> drivers = null;
            HPOphenotype objGeneSymbolSearch = new HPOphenotype();
            var querySQL = "";

            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    //string term = "%" + SearchGeneSymbol + "%";
                    //param.Add("@searchHPO", term);
                    /* 1
                    	If symbol matches hgnc_symbol (hgnc_gene_info) then display hgnc_symbol (hgnc_gene_info) 
                    on the UI and use the corresponding hgnc_id (hgnc_gene_info) and gene_id (hgnc_gene_info) to move around in the DB.
                     */
                    querySQL = @"select  hpoid + ' ' + hpolabel as hpolabel ,hpoid from public.public_hpo_phenotype";
                    var driverListcase1 = await dbConnection.QueryAsync<HPOphenotype>(querySQL, commandType: CommandType.Text);
                    drivers = driverListcase1.ToList();





                }
            }
            catch (Exception e)
            {
            }


            return drivers;
        }
    }
}
