﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class MasterUserController : ControllerBase
    {
        private readonly IMasterUserService _masteruserService;

        public MasterUserController(IMasterUserService masterUserService)
        {

            _masteruserService = masterUserService;

        }

        /// <summary>
        /// gets the statuscode from AddUser method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="adduser"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddUser")]
        [ActionName("AddUser"), Authorize]
        public async Task<ActionResult> AddUser([FromBody] MasterUser user)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _masteruserService.AddUser(user);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("UpdateUser")]
        [ActionName("UpdateUser"), Authorize]
        public async Task<ActionResult> UpdateUser([FromBody] MasterUser user)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _masteruserService.UpdateUser(user);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("ActivateUserById")]
        [ActionName("ActivateUserById"), Authorize]
        public async Task<ActionResult> ActivateUserById([FromBody] MasterUser user)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _masteruserService.ActivateUserById(user);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }
        [HttpPost]
        [Route("DeactivateUserById")]
        [ActionName("DeactivateUserById"), Authorize]
        public async Task<ActionResult> DeactivateUserById([FromBody] MasterUser user)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _masteruserService.DeactivateUserById(user);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetUserById/{userId}")]
        [ActionName("GetUserById"), Authorize]
        public async Task<ActionResult> GetUserById(int userId)
        {
            var driver = await _masteruserService.GetUserById(userId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All User Data By Id");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetAllUser")]
        [ActionName("GetAllUser"), Authorize]
        public async Task<ActionResult> GetAllUser()
        {

            var driver = await _masteruserService.GetAllUser();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All User Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }


    }
}
