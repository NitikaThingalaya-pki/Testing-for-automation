﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class MasterRoleController : ControllerBase
    {
        private readonly IMasterRoleService _masterroleService;

        public MasterRoleController(IMasterRoleService masterRoleService)
        {

            _masterroleService = masterRoleService;

        }

        [HttpGet]
        [Route("GetAllRoles")]
        [ActionName("GetAllRoles"), Authorize]
        public async Task<ActionResult> GetAllRoles()
        {

            var driver = await _masterroleService.GetAllRoles();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Roles Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }


    }
}
