﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class AssayController : ControllerBase
    {

        private readonly IAssayService _assayService;

        public AssayController(IAssayService assayService)
        {

            _assayService = assayService;

        }

        /// <summary>
        /// gets the statuscode from AddAssay method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addassay"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssay")]
        [ActionName("AddAssay"), Authorize]
        public async Task<ActionResult> AddAssay([FromBody] MasterAssay assay)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assayService.AddAssay(assay);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                responseDetails.ResponseData = driver[0].ResponseData;
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                responseDetails.ResponseData = driver[0].ResponseData;
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("UpdateAssay")]
        [ActionName("UpdateAssay"), Authorize]
        public async Task<ActionResult> UpdateAssay([FromBody] MasterAssay assay)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assayService.UpdateAssay(assay);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }


        [HttpPost]
        [Route("DeleteAssayById")]
        [ActionName("DeleteAssayById"), Authorize]
        public async Task<ActionResult> DeleteAssayById([FromBody] MasterAssay assay)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assayService.DeleteAssayById(assay);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("ActivateAssayById")]
        [ActionName("ActivateAssayById"), Authorize]
        public async Task<ActionResult> ActivateAssayById([FromBody] MasterAssay assay)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assayService.ActivateAssayById(assay);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }
        [HttpPost]
        [Route("DeactivateAssayById")]
        [ActionName("DeactivateAssayById"), Authorize]
        public async Task<ActionResult> DeactivateAssayById([FromBody] MasterAssay assay)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assayService.DeactivateAssayById(assay);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetAssayById/{assayId}")]
        [ActionName("GetAssayById"), Authorize]
        public async Task<ActionResult> GetAssayById(int assayId)
        {
            var driver = await _assayService.GetAssayById(assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Assay Data By Id");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }


        [HttpGet]
        [Route("GetAssayByIdCRUD/{assayId}")]
        [ActionName("GetAssayByIdCRUD"), Authorize]
        public async Task<ActionResult> GetAssayByIdCRUD(int assayId)
        {
            var driver = await _assayService.GetAssayByIdCRUD(assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Assay Data By Id");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }


        [HttpGet]
        [Route("GetAllAssay")]
        [ActionName("GetAllAssay"), Authorize]
        public async Task<ActionResult> GetAllAssay()
        {
            var driver = await _assayService.GetAllAssay();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Assay Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetTabFilterCategories/{assayId}")]
        [ActionName("GetTabFilterCategories"), Authorize]
        public async Task<ActionResult> GetTabFilterCategories(int assayId)
        {
            var driver = await _assayService.GetTabFilterCategories(assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Assay Tab Filter Category Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("CheckAssay/{AssayName}")]
        [ActionName("CheckAssay"), Authorize]
        public async Task<ActionResult> CheckAssay(string AssayName)
        {
            var driver = await _assayService.CheckAssay(AssayName);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Error While Checking Duplicate !!");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            //responseDetails.ResponseData = driver[0].ResponseData;
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("EditCheckAssay/{AssayName}")]
        [ActionName("EditCheckAssay"), Authorize]
        public async Task<ActionResult> EditCheckAssay(string AssayName)
        {
            var driver = await _assayService.EditCheckAssay(AssayName);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Error While Checking Duplicate !!");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            //responseDetails.ResponseData = driver[0].ResponseData;
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }


    }
}
