﻿using ODIN2_Modules;

namespace ODIN2_API.Repositories.Interface
{
    public interface IRegisterAsyncRepository
    {
        Task<List<BaseResponseStatus>> RegisterUser(MasterUser register);
    }
}
