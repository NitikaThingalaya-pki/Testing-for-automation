﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssayViewService : BaseAsyncRepository, IAssayViewService
    {
        public AssayViewService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssayView
        /// </summary>
        /// <param name="addAssayView"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssayView(AssayView AssayView)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssayView(
                                    '" + AssayView.AssayId + "'," +
                                    "'" + AssayView.TabId + "'," +
                                    "'" + AssayView.Gene + "'," +
                                    "'" + AssayView.HGVS + "'," +
                                    "'" + AssayView.Zygosity + "'," +
                                    "'" + AssayView.Exon + "'," +
                                    "'" + AssayView.ReadDepth + "'," +
                                    "'" + AssayView.AltPercentage + "'," +
                                    "'" + AssayView.InternalFrequency + "'," +
                                    "'" + AssayView.InternalClassification + "'," +
                                    "'" + AssayView.OMIMPhenotype + "'," +
                                    "'" + AssayView.OMIMInheritance + "'," +
                                    "'" + AssayView.HGMDClassification + "'," +
                                    "'" + AssayView.ClinVarClassification + "'," +
                                    "'" + AssayView.gnomADHighestFrequency + "'," +
                                    "'" + AssayView.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssayView
        /// </summary>
        /// <param name="UpdateAssayView"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssayView(AssayView AssayView)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssayView(
                                    '" + AssayView.AssayId + "'," +
                                    "'" + AssayView.TabId + "'," +
                                    "'" + AssayView.Gene + "'," +
                                    "'" + AssayView.HGVS + "'," +
                                    "'" + AssayView.Zygosity + "'," +
                                    "'" + AssayView.Exon + "'," +
                                    "'" + AssayView.ReadDepth + "'," +
                                    "'" + AssayView.AltPercentage + "'," +
                                    "'" + AssayView.InternalFrequency + "'," +
                                    "'" + AssayView.InternalClassification + "'," +
                                    "'" + AssayView.OMIMPhenotype + "'," +
                                    "'" + AssayView.OMIMInheritance + "'," +
                                    "'" + AssayView.HGMDClassification + "'," +
                                    "'" + AssayView.ClinVarClassification + "'," +
                                    "'" + AssayView.gnomADHighestFrequency + "'," +
                                    "'" + AssayView.UpdatedBy + "');";

                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }


    }
}
