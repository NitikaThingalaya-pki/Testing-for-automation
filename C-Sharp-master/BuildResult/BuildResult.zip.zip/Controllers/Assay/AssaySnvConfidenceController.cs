﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class AssaySnvConfidenceController : ControllerBase
    {
        private readonly IAssaySnvConfidenceService _assaySnvConfidenceService;

        public AssaySnvConfidenceController(IAssaySnvConfidenceService assaySnvConfidenceService)
        {
            _assaySnvConfidenceService = assaySnvConfidenceService;
        }

        /// <summary>
        /// gets the statuscode from AddAssaySnvConfidence method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssaySnvConfidence"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssaySnvConfidence")]
        [ActionName("AddAssaySnvConfidence"), Authorize]
        public async Task<ActionResult> AddAssaySnvConfidence([FromBody] AssaySnvConfidence assaySnvConfidence)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvConfidenceService.AddAssaySnvConfidence(assaySnvConfidence);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }


        [HttpGet]
        [Route("GetAssaySnvConfidenceById/{tabId}&{assayId}")]
        [ActionName("GetAssaySnvConfidenceById"), Authorize]
        public async Task<ActionResult> GetAssaySnvConfidenceById(int tabId, int assayId)
        {
            var driver = await _assaySnvConfidenceService.GetAssaySnvConfidenceById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("AssaySnvConfidence Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateAssaySnvConfidence")]
        [ActionName("UpdateAssaySnvConfidence"), Authorize]
        public async Task<ActionResult> UpdateAssaySnvConfidence([FromBody] AssaySnvConfidence assaySnvConfidence)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvConfidenceService.UpdateAssaySnvConfidence(assaySnvConfidence);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }

    }
}
