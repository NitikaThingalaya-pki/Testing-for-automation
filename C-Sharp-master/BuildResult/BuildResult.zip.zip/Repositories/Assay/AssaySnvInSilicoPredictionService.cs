﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssaySnvInSilicoPredictionService : BaseAsyncRepository, IAssaySnvInSilicoPredictionService
    {
        public AssaySnvInSilicoPredictionService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the AssaySnvInSilicoPrediction
        /// </summary>
        /// <param name="addAssaySnvInSilicoPrediction"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssaySnvInSilicoPrediction(AssaySnvInSilicoPrediction assaySnvInSilicoPrediction)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssaySnvInSilicoPrediction(
                                    '" + assaySnvInSilicoPrediction.AssayId + "'," +
                                    "'" + assaySnvInSilicoPrediction.TabId + "'," +
                                    "'" + assaySnvInSilicoPrediction.REVELDDL + "'," +
                                    "'" + assaySnvInSilicoPrediction.REVELValue + "'," +
                                    "'" + assaySnvInSilicoPrediction.SpliceAlDDL + "'," +
                                    "'" + assaySnvInSilicoPrediction.SpliceAlValue + "'," +
                                    "'" + assaySnvInSilicoPrediction.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the tab by tabid and assayid
        /// </summary>
        /// <param name="getassaySnvInSilicoPredictionbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<AssaySnvInSilicoPrediction> GetAssaySnvInSilicoPredictionById(int tabId, int assayId)
        {
            AssaySnvInSilicoPrediction drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select AssaySNVInSilicoPredictionId,AssayId,TabId,
                                        REVELDDL,REVELValue,SpliceAlDDL,SpliceAlValue,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_SNV_InSilicoPrediction 
                                        where 
                                        tabId =" + tabId + " and AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<AssaySnvInSilicoPrediction>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }
            return drivers;
        }

        /// <summary>
        /// To update the UpdateAssaySnvInSilicoPrediction
        /// </summary>
        /// <param name="UpdateAssaySnvInSilicoPrediction"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssaySnvInSilicoPrediction(AssaySnvInSilicoPrediction assaySnvInSilicoPrediction)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateAssaySNVInSilicoPrediction(
                                    '" + assaySnvInSilicoPrediction.AssayId + "'," +
                                    "'" + assaySnvInSilicoPrediction.TabId + "'," +
                                    "'" + assaySnvInSilicoPrediction.REVELDDL + "'," +
                                    "'" + assaySnvInSilicoPrediction.REVELValue + "'," +
                                    "'" + assaySnvInSilicoPrediction.SpliceAlDDL + "'," +
                                    "'" + assaySnvInSilicoPrediction.SpliceAlValue + "'," +
                                    "'" + assaySnvInSilicoPrediction.UpdatedBy + "');";

                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

    }
}
