﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface IAssayService
    {
        Task<List<BaseResponseStatus>> AddAssay(MasterAssay assay);
        Task<List<BaseResponseStatus>> UpdateAssay(MasterAssay assay);
        Task<List<BaseResponseStatus>> DeleteAssayById(MasterAssay assay);
        Task<List<BaseResponseStatus>> ActivateAssayById(MasterAssay assay);
        Task<List<BaseResponseStatus>> DeactivateAssayById(MasterAssay assay);
        Task<MasterAssay> GetAssayById(int assayId);

        Task<MasterAssayCRUD> GetAssayByIdCRUD(int assayId);
        Task<List<MasterAssayCRUD>> GetAllAssay();
        Task<MasterAssayCRUD> GetTabFilterCategories(int assayId);

        Task<List<BaseResponseStatus>> CheckAssay(string AssayName);

        Task<List<BaseResponseStatus>> EditCheckAssay(string AssayName);
    }
}
