﻿using Dapper;
using ODIN2_API.Repositories.Interface.Comman;
using ODIN2_Modules.Comman;
using System.Data;
using System.Data.Common;


namespace ODIN2_API.Repositories.Comman
{
    public class omim_morbidmapservice : BaseAsyncRepository, Iomim_morbidmap
    {
        public omim_morbidmapservice(IConfiguration configuration) : base(configuration)
        {
        }

        public async Task<List<omim_morbidmap>> GetAllOmimmordimapPhenotype(string SearchGeneSymbol)
        {
            List<omim_morbidmap> drivers = null;
          
            var querySQL = "";

            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    string term = "%" + SearchGeneSymbol + "%";
                    param.Add("@search", term);

                    querySQL = @"select top 10 mimnumber,phenotype from public_omim_morbidmap where  phenotype like @search";
                    var driverListcase1 = await dbConnection.QueryAsync<omim_morbidmap>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverListcase1.ToList();





                }
            }
            catch (Exception e)
            {
            }


            return drivers;
        }
    }
}
