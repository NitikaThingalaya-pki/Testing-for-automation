﻿using ODIN2_Modules;
using ODIN2_Modules.Case;

namespace ODIN2_API.Repositories.Interface.Case
{
    public interface ICaseService
    {
        Task<List<CaseMasterClient>> GetAllActiveClient();
        Task<List<CaseMasterAssay>> GetAllAssay();
        Task<List<CaseMasterAnalysisType>> GetAllAnalysisType();
        Task<List<BaseResponseStatus>> AddCaseDetails(CaseDetails caseDetails);
        Task<List<CaseMasterGender>> GetGender();
        Task<List<CaseMasterConsanguinity>> GetConsanguinity();
        Task<List<BaseResponseStatus>> AddCaseProbandInformation(CaseProbandInformation caseProbandInformation);
        Task<List<BaseResponseStatus>> AddCasePhenotypes(CasePhenotypes casePhenotypes);
        Task<List<BaseResponseStatus>> AddCaseGeneList(CaseGeneList caseGeneList);
        Task<List<BaseResponseStatus>> AddCaseFamilyTree(CaseFamilyTree caseFamilyTree);

        Task<List<CaseDetails>> GetCaseDetailsByStatusId(int statusId);
        Task<CaseSectionsData> GetCaseSectionsDataByCaseId(int caseId);

        Task<CaseDetails> GetCaseDetailsByCaseId(int caseId);
        Task<CaseProbandInformation> GetCaseProbandInformationByCaseId(int caseId);
        Task<CasePhenotypes> GetCasePhenotypesByCaseId(int caseId);
        Task<CaseGeneList> GetCaseGeneListByCaseId(int caseId);
        Task<List<CaseFamilyTree>> GetCaseFamilyTreeByCaseId(int caseId);
        Task<List<BaseResponseStatus>> UpdateCaseNotes(CaseDetails caseDetails);
    }
}
