﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Assay
{
    public class AssayService : BaseAsyncRepository, IAssayService
    {
        public AssayService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To add the assay master
        /// </summary>
        /// <param name="addassay"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddAssay(MasterAssay assay)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertAssay('" + assay.AssayName + "','" + assay.BaitName + "','" + assay.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To update the assay master
        /// </summary>
        /// <param name="updateassay"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateAssay(MasterAssay assay)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spUpdateAssay('" + assay.AssayId + "','" + assay.AssayName + "','" + assay.BaitName + "','" + assay.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To delete the assay by id
        /// </summary>
        /// <param name="deleteassaybyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> DeleteAssayById(MasterAssay assay)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spDeleteAssayById('" + assay.AssayId + "','" + assay.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To activate the assay by id
        /// </summary>
        /// <param name="activateassaybyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> ActivateAssayById(MasterAssay assay)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spActivateAssayById('" + assay.AssayId + "','" + assay.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To deactivate the assay by id
        /// </summary>
        /// <param name="deactivateassaybyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> DeactivateAssayById(MasterAssay assay)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spDeactivateAssayById('" + assay.AssayId + "','" + assay.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To get the assay master data 
        /// </summary>
        /// <param name="getallassay"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<MasterAssayCRUD>> GetAllAssay()
        {
            List<MasterAssayCRUD> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select assayid,assayname,baitname,isactive,createdby,createddate,updatedby,updateddate from assay_master where IsCompleteDeleted=false;";
                    var driverList = await dbConnection.QueryAsync<MasterAssayCRUD>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To add the assay by id
        /// </summary>
        /// <param name="getassaybyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<MasterAssay> GetAssayById(int assayId)
        {
            MasterAssay drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select assayid,assayname,baitname,isactive,createdby,createddate,updatedby,updateddate from assay_master  where AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<MasterAssay>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        public async Task<MasterAssayCRUD> GetTabFilterCategories(int assayId)
        {
            MasterAssayCRUD masterAssayCRUD = new MasterAssayCRUD();
            masterAssayCRUD.TabList = new List<AssayTabList>();

            using (DbConnection dbConnection = SqlWriterConnection)
            {
                await dbConnection.OpenAsync();

                // get all tabids from assayid -- single query  (assayid)

                var querySQL = @"select tabid, tabname from assay_tab_master where  AssayId=" + assayId + ";";
                // parameter passing @tabid
                var masterTabs = await dbConnection.QueryAsync<MasterTab>(querySQL, null, commandType: CommandType.Text);
                
                foreach (var tab in masterTabs)
                {
                    AssayTabList assayTabList = new AssayTabList();

                    assayTabList.TabId = tab.TabId;
                    assayTabList.tabName = tab.TabName;
                    // 1 Confidence
                    AssaySnvConfidence assaySnvConfidence = new AssaySnvConfidence();
                    querySQL = @"select 
                                     AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
                                     VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
                                    ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
                                    ,CreatedBy,Createddate,UpdatedBy,Updateddate 
                                    from Assay_SNV_Confidence where 
                                    tabId =" + tab.TabId + " and AssayId=" + assayId + ";";
                    // parameter passing @tabid
                    var driverListSnvConfidence = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
                    assaySnvConfidence = driverListSnvConfidence.FirstOrDefault();
                    assayTabList.Confidence = assaySnvConfidence;

                    // 2 VariantType
                    AssaySnvVariantType assaySnvVariantType = new AssaySnvVariantType();
                    querySQL = @"select 
                                     AssaySNVVariantTypeId,AssayId,TabId,VariantTypeDDL,
                                    CreatedBy,Createddate,UpdatedBy,Updateddate
                                    from Assay_SNV_VariantType where 
                                    tabId =" + tab.TabId + " and AssayId=" + assayId + ";";

                    var driverListSnvVariantType = await dbConnection.QueryAsync<AssaySnvVariantType>(querySQL, null, commandType: CommandType.Text);
                    assaySnvVariantType = driverListSnvVariantType.FirstOrDefault();
                    assayTabList.VariantType = assaySnvVariantType;

                    //// 3 VariantLocation
                    AssaySnvVariantLocation assaySnvVariantLocation = new AssaySnvVariantLocation();
                    querySQL = @"select AssaySNVVariantLocationId,AssayId,TabId,
                                        PositionStartDDL,PositionStartValue,PositionEndDDL,PositionEndValue,ChromosomeDDL,
                                        BEDFileName,BEDFilePath,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_SNV_VariantLocation 
                                        where 
                                        tabId =" + tab.TabId + " and AssayId=" + assayId + ";";

                    var driverListSnvVariantLocation = await dbConnection.QueryAsync<AssaySnvVariantLocation>(querySQL, null, commandType: CommandType.Text);
                    assaySnvVariantLocation = driverListSnvVariantLocation.FirstOrDefault();
                    assayTabList.VariantLocation = assaySnvVariantLocation;

                    //// 4 VariantClassification
                    AssaySnvVariantClassification assaySnvVariantClassification = new AssaySnvVariantClassification();
                    querySQL = @"select AssaySNVVariantClassificationId,AssayId,TabId,
                                    HGMDMSDDL,ClinVarMSDDL,ODINMSDDL,
                                    CreatedBy,Createddate,UpdatedBy,Updateddate 
                                    from Assay_SNV_VariantClassification where 
                                    tabId =" + tab.TabId + " and AssayId=" + assayId + ";";

                    var driverListSnvVariantClassification = await dbConnection.QueryAsync<AssaySnvVariantClassification>(querySQL, null, commandType: CommandType.Text);
                    assaySnvVariantClassification = driverListSnvVariantClassification.FirstOrDefault();
                    assayTabList.VariantClassification = assaySnvVariantClassification;

                    //// 5 InSilicoPrediction
                    AssaySnvInSilicoPrediction assaySnvInSilicoPrediction = new AssaySnvInSilicoPrediction();
                    querySQL = @"select AssaySNVInSilicoPredictionId,AssayId,TabId,
                                        REVELDDL,REVELValue,SpliceAlDDL,SpliceAlValue,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_SNV_InSilicoPrediction 
                                        where 
                                        tabId =" + tab.TabId + " and AssayId=" + assayId + ";";

                    var driverListSnvInSilicoPrediction = await dbConnection.QueryAsync<AssaySnvInSilicoPrediction>(querySQL, null, commandType: CommandType.Text);
                    assaySnvInSilicoPrediction = driverListSnvInSilicoPrediction.FirstOrDefault();
                    assayTabList.InSillicoPrediction = assaySnvInSilicoPrediction;

                    //// 6 PopulationFrequency
                    AssaySnvPopulationFrequency assaySnvPopulationFrequency = new AssaySnvPopulationFrequency();
                    querySQL = @"select AssaySNVPopulationFrequencyId,AssayId,TabId,
                                        gnomADDDL,gnomADValue,ESP6500DDL,ESP6500Value,
                                        GMEDDL,GMEValue,ODINDDL,ODINValue,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_SNV_PopulationFrequency 
                                        where 
                                        tabId =" + tab.TabId + " and AssayId=" + assayId + ";";

                    var driverListSnvPopulationFrequency = await dbConnection.QueryAsync<AssaySnvPopulationFrequency>(querySQL, null, commandType: CommandType.Text);
                    assaySnvPopulationFrequency = driverListSnvPopulationFrequency.FirstOrDefault();
                    assayTabList.PopulationFrequancy = assaySnvPopulationFrequency;

                    //// 7 Inheritance
                    AssaySnvInheritance assaySnvInheritance = new AssaySnvInheritance();
                    querySQL = @"select AssaySNVInheritanceId,AssayId,TabId,
                                        InheritanceMSDDL,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_SNV_Inheritance 
                                        where 
                                        tabId =" + tab.TabId + " and AssayId=" + assayId + ";";

                    var driverListSnvInheritance = await dbConnection.QueryAsync<AssaySnvInheritance>(querySQL, null, commandType: CommandType.Text);
                    assaySnvInheritance = driverListSnvInheritance.FirstOrDefault();
                    assayTabList.Inheritance = assaySnvInheritance;

                    //// 8 GeneList
                    AssayGeneGeneList assayGeneGeneList = new AssayGeneGeneList();
                    querySQL = @"select AssayGeneGeneListId,AssayId,TabId,
                                        HPOMSDDL,OMIMMSDDL,HGMDMSDDL,ClinvarMSDDL,OrphanetMSDDL,
                                        HPOMSDDLTEXT,OMIMMSDDLTEXT,HGMDMSDDLTEXT,ClinvarMSDDLTEXT,OrphanetMSDDLTEXT,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_Gene_GeneList 
                                        where 
                                        tabId =" + tab.TabId + " and AssayId=" + assayId + ";";

                    var driverListGeneGeneList = await dbConnection.QueryAsync<AssayGeneGeneList>(querySQL, null, commandType: CommandType.Text);
                    assayGeneGeneList = driverListGeneGeneList.FirstOrDefault();
                    assayTabList.GeneGeneList = assayGeneGeneList;

                    //// 9 AssayView
                    AssayView assayView = new AssayView();
                    querySQL = @"select AssayViewId,AssayId,TabId,
                                        Gene,HGVS,Zygosity,Exon,ReadDepth,
                                        AltPercentage,InternalFrequency,InternalClassification,OMIMPhenotype,
                                        OMIMInheritance,HGMDClassification,ClinVarClassification,gnomADHighestFrequency,
                                        CreatedBy,Createddate,UpdatedBy,Updateddate 
                                        from Assay_View 
                                        where 
                                        tabId =" + tab.TabId + " and AssayId=" + assayId + ";";

                    var driverListView = await dbConnection.QueryAsync<AssayView>(querySQL, null, commandType: CommandType.Text);
                    assayView = driverListView.FirstOrDefault();
                    assayTabList.View = assayView;

                    masterAssayCRUD.TabList.Add(assayTabList);
                }
                                              
            }
            return masterAssayCRUD;
        }

        /// <summary>
        /// To add the assay master
        /// </summary>
        /// <param name="addassay"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> CheckAssay(string AssayName)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spcheckassay('" + AssayName + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


        public async Task<List<BaseResponseStatus>> EditCheckAssay(string AssayName)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                string[] strArray = AssayName.Split('~');

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call speditcheckassay('" + strArray[0] + "','" + strArray[1] + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }








        //public async Task<TabFilterCategories> GetTabFilterCategoriesOld(int tabId, int assayId)
        //{
        //    TabFilterCategories tabFilterCategories = new TabFilterCategories();

        //    using (DbConnection dbConnection = SqlWriterConnection)
        //    {
        //        await dbConnection.OpenAsync();

        //        // 1
        //        var querySQL = @"select 
        //                             AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
        //                             VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
        //                            ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
        //                            ,CreatedBy,Createddate,UpdatedBy,Updateddate 
        //                            from Assay_SNV_Confidence where 
        //                            tabId =" + tabId + " and AssayId=" + assayId + ";";
        //        // parameter passing @tabid
        //        var driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
        //        tabFilterCategories.AssaySnvConfidence = driverList.FirstOrDefault();
        //        // 2
        //        querySQL = @"select 
        //                             AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
        //                             VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
        //                            ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
        //                            ,CreatedBy,Createddate,UpdatedBy,Updateddate 
        //                            from Assay_SNV_Confidence where 
        //                            tabId =" + tabId + " and AssayId=" + assayId + ";";

        //        driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
        //        tabFilterCategories.AssaySnvConfidence = driverList.FirstOrDefault();
        //        // 3
        //        querySQL = @"select 
        //                             AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
        //                             VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
        //                            ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
        //                            ,CreatedBy,Createddate,UpdatedBy,Updateddate 
        //                            from Assay_SNV_Confidence where 
        //                            tabId =" + tabId + " and AssayId=" + assayId + ";";

        //        driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
        //        tabFilterCategories.AssaySnvConfidence = driverList.FirstOrDefault();
        //        // 4
        //        querySQL = @"select 
        //                             AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
        //                             VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
        //                            ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
        //                            ,CreatedBy,Createddate,UpdatedBy,Updateddate 
        //                            from Assay_SNV_Confidence where 
        //                            tabId =" + tabId + " and AssayId=" + assayId + ";";

        //        driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
        //        tabFilterCategories.AssaySnvConfidence = driverList.FirstOrDefault();
        //        // 5
        //        querySQL = @"select 
        //                             AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
        //                             VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
        //                            ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
        //                            ,CreatedBy,Createddate,UpdatedBy,Updateddate 
        //                            from Assay_SNV_Confidence where 
        //                            tabId =" + tabId + " and AssayId=" + assayId + ";";

        //        driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
        //        tabFilterCategories.AssaySnvConfidence = driverList.FirstOrDefault();
        //        // 6
        //        querySQL = @"select 
        //                             AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
        //                             VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
        //                            ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
        //                            ,CreatedBy,Createddate,UpdatedBy,Updateddate 
        //                            from Assay_SNV_Confidence where 
        //                            tabId =" + tabId + " and AssayId=" + assayId + ";";

        //        driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
        //        tabFilterCategories.AssaySnvConfidence = driverList.FirstOrDefault();
        //        // 7
        //        querySQL = @"select 
        //                             AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
        //                             VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
        //                            ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
        //                            ,CreatedBy,Createddate,UpdatedBy,Updateddate 
        //                            from Assay_SNV_Confidence where 
        //                            tabId =" + tabId + " and AssayId=" + assayId + ";";

        //        driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
        //        tabFilterCategories.AssaySnvConfidence = driverList.FirstOrDefault();
        //        // 8
        //        querySQL = @"select 
        //                             AssaySNVConfidenceId,AssayId,TabId,CallQualityDDL,CallQualityValue,
        //                             VariantFilterDDL,MappingQualityDDL,MappingQualityValue,GenotypeQualityDDL,GenotypeQualityValue 
        //                            ,ReadDepthDDL,ReadDepthValue,AltPercentageDDL,AltPercentageValue
        //                            ,CreatedBy,Createddate,UpdatedBy,Updateddate 
        //                            from Assay_SNV_Confidence where 
        //                            tabId =" + tabId + " and AssayId=" + assayId + ";";

        //        driverList = await dbConnection.QueryAsync<AssaySnvConfidence>(querySQL, null, commandType: CommandType.Text);
        //        tabFilterCategories.AssaySnvConfidence = driverList.FirstOrDefault();

        //    }
        //    return tabFilterCategories;
        //}




        public async Task<MasterAssayCRUD> GetAssayByIdCRUD(int assayId)
        {
            MasterAssayCRUD drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select assayid, assayname, baitname, '5' as drpCheck, assayname,isactive,createdby,createddate,updatedby,updateddate from assay_master  where AssayId=" + assayId + ";";
                    var driverList = await dbConnection.QueryAsync<MasterAssayCRUD>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.FirstOrDefault();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

    }
}
