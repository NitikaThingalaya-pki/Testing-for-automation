﻿using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Repositories.Interface.Assay
{
    public interface ITabService
    {
        Task<List<BaseResponseStatus>> AddTab(MasterTab tab);
        Task<List<BaseResponseStatus>> UpdateTab(MasterTab tab);
        Task<MasterTab> GetTabById(int tabId, int assayId);
    }
}
