﻿using ODIN2_Modules.Comman;

namespace ODIN2_API.Repositories.Interface.Comman
{
    public interface IHPOphenotype
    {
        Task<List<HPOphenotype>> GetAllHPOPhenotype(string SearchGeneSymbol);

        Task<List<HPOphenotype>> GetAllHPOPhenotypeList();

        
    }
}
