﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_API.Repositories.Interface.Comman;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Comman
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class GeneSymbolSearchController : ControllerBase
    {
        private readonly IGeneSymbolSearch _geneSymbolSearch;

        public GeneSymbolSearchController(IGeneSymbolSearch geneSymbolSearch)
        {

            _geneSymbolSearch = geneSymbolSearch;

        }

        [HttpGet]
        [Route("GeneSymbolSearchResult/{SearchGeneSymbol}")]
        [ActionName("GeneSymbolSearchResult")]
        public async Task<ActionResult> GeneSymbolSearchResult(string SearchGeneSymbol)
        {
           var driver = await _geneSymbolSearch.GeneSymbolSearchResult(SearchGeneSymbol);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
             if (driver == null)
            {
                var returnMsg = string.Format("All GeneSymbolSearchResult");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }
    }
}
