﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class ClientController : ControllerBase
    {

        private readonly IClientService _clientService;

        public ClientController(IClientService clientService)
        {

            _clientService = clientService;

        }

        /// <summary>
        /// gets the statuscode from AddClient method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addclient"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddClient")]
        [ActionName("AddClient"), Authorize]
        public async Task<ActionResult> AddClient([FromBody] MasterClient client)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _clientService.AddClient(client);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("UpdateClient")]
        [ActionName("UpdateClient"), Authorize]
        public async Task<ActionResult> UpdateClient([FromBody] MasterClient client)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _clientService.UpdateClient(client);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }


        [HttpPost]
        [Route("DeleteClientById")]
        [ActionName("DeleteClientById"), Authorize]
        public async Task<ActionResult> DeleteClientById([FromBody] MasterClient client)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _clientService.DeleteClientById(client);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("ActivateClientById")]
        [ActionName("ActivateClientById"), Authorize]
        public async Task<ActionResult> ActivateClientById([FromBody] MasterClient client)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _clientService.ActivateClientById(client);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }
        [HttpPost]
        [Route("DeactivateClientById")]
        [ActionName("DeactivateClientById"), Authorize]
        public async Task<ActionResult> DeactivateClientById([FromBody] MasterClient client)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _clientService.DeactivateClientById(client);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetClientById/{clientId}")]
        [ActionName("GetClientById"), Authorize]
        public async Task<ActionResult> GetClientById(int clientId)
        {
            var driver = await _clientService.GetClientById(clientId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Client Data By Id");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetAllClient")]
        [ActionName("GetAllClient"), Authorize]
        public async Task<ActionResult> GetAllClient()
        {

            var driver = await _clientService.GetAllClient();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Client Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetAllActiveClient")]
        [ActionName("GetAllActiveClient"), Authorize]
        public async Task<ActionResult> GetAllActiveClient()
        {

            var driver = await _clientService.GetAllActiveClient();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All Active Client Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }

    }
}
