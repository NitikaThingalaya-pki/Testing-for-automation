﻿using ODIN2_Modules.Comman;

namespace ODIN2_API.Repositories.Interface.Comman
{
    public interface Iomim_morbidmap
    {
        Task<List<omim_morbidmap>> GetAllOmimmordimapPhenotype(string SearchGeneSymbol);
    }
}
