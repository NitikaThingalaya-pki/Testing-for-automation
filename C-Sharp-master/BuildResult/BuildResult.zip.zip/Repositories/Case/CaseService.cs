﻿using System.Data;
using System.Data.Common;
using Dapper;
using Nest;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Case;
using ODIN2_Modules;
using ODIN2_Modules.Assay;
using ODIN2_Modules.Case;

namespace ODIN2_API.Repositories.Case
{
    public class CaseService : BaseAsyncRepository, ICaseService
    {
        public CaseService(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// To get the active client
        /// </summary>
        /// <param name="GetAllActiveClient"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<CaseMasterClient>> GetAllActiveClient()
        {
            List<CaseMasterClient> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select clientid,clientname,0 as Noofprocessedcases,isactive,createdby,createddate,updatedby,updateddate,s3foldercreated from master_client where IsCompleteDeleted=false and IsActive=true and s3foldercreated=true;";
                    var driverList = await dbConnection.QueryAsync<CaseMasterClient>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To get the analysis type
        /// </summary>
        /// <param name="GetAllAnalysisType"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<CaseMasterAnalysisType>> GetAllAnalysisType()
        {
            List<CaseMasterAnalysisType> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select AnalysisTypeId,AnalysisType from Case_AnalysisType_Master where isactive=1;";
                    var driverList = await dbConnection.QueryAsync<CaseMasterAnalysisType>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the assay  data 
        /// </summary>
        /// <param name="getallassay"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<CaseMasterAssay>> GetAllAssay()
        {                     
                List<CaseMasterAssay> drivers = null;
                try
                {
                    using (DbConnection dbConnection = SqlWriterConnection)
                    {
                        await dbConnection.OpenAsync();

                        var querySQL = @"select assayid,assayname,isactive,createdby,createddate,updatedby,updateddate from assay_master where IsCompleteDeleted=false and IsActive=true;";
                        var driverList = await dbConnection.QueryAsync<CaseMasterAssay>(querySQL, null, commandType: CommandType.Text);
                        drivers = driverList.ToList();
                    }
                }
                catch (Exception e)
                {
                }

                return drivers;            
        }

        /// <summary>
        /// To add the Case Details
        /// </summary>
        /// <param name="AddCaseDetails"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddCaseDetails(CaseDetails caseDetails)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@ClientId", caseDetails.ClientId);
                param.Add("@CaseName", caseDetails.CaseName);
                param.Add("@TestName", caseDetails.TestName);
                param.Add("@AssayId", caseDetails.AssayId);
                param.Add("@AnalysisTypesIdMSDDL", caseDetails.AnalysisTypesIdMSDDL);
                //param.Add("@DueDate", caseDetails.DueDate);
                param.Add("@DueDate",  Convert.ToDateTime(caseDetails.DueDate));
                param.Add("@CaseNotes", caseDetails.CaseNotes);
                param.Add("@StatusId", caseDetails.StatusId);
                param.Add("@Stat", caseDetails.Stat);
                param.Add("@FlagId", caseDetails.FlagId);
                param.Add("@CreatedBy", caseDetails.CreatedBy);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spinsertCaseDetails(@ClientId,@CaseName,
                               @TestName,@AssayId,@AnalysisTypesIdMSDDL,@DueDate,@CaseNotes,
                               @StatusId,@Stat,@FlagId,@CreatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the gender  data 
        /// </summary>
        /// <param name="GetGender"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<CaseMasterGender>> GetGender()
        {
            List<CaseMasterGender> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select genderid,gender,isactive,createdby,createddate,updatedby,updateddate from Case_Gender_Master where IsCompleteDeleted=false and IsActive=true;";
                    var driverList = await dbConnection.QueryAsync<CaseMasterGender>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To get the Consanguinity  data 
        /// </summary>
        /// <param name="GetConsanguinity"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<CaseMasterConsanguinity>> GetConsanguinity()
        {
            List<CaseMasterConsanguinity> drivers = null;
            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select Consanguinityid,Consanguinity,isactive,createdby,createddate,updatedby,updateddate from Case_Consanguinity_Master where IsCompleteDeleted=false and IsActive=true;";
                    var driverList = await dbConnection.QueryAsync<CaseMasterConsanguinity>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To add the Case Proband Information Details
        /// </summary>
        /// <param name="AddCaseProbandInformation"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddCaseProbandInformation(CaseProbandInformation caseProbandInformation)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@AccessionId", caseProbandInformation.AccessionId);
                param.Add("@CaseId", caseProbandInformation.CaseId);
                param.Add("@GenderId", caseProbandInformation.GenderId);
                param.Add("@DateOfBirth", Convert.ToDateTime(caseProbandInformation.DateOfBirth));
                param.Add("@Age", caseProbandInformation.Age);
                param.Add("@Ethnicity", caseProbandInformation.Ethnicity);
                param.Add("@ConsanguinityId", caseProbandInformation.ConsanguinityId);
                param.Add("@CreatedBy", caseProbandInformation.CreatedBy);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spinsertCaseProbandInformation(@AccessionId,@CaseId,
                                   @GenderId,@DateOfBirth,@Age,@Ethnicity,@ConsanguinityId,@CreatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To add the Case Phenotypes Details
        /// </summary>
        /// <param name="AddCasePhenotypes"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddCasePhenotypes(CasePhenotypes casePhenotypes)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@PhenotypesMSDDL", casePhenotypes.PhenotypesMSDDL);
                param.Add("@PhenotypesMSDDLTEXT", casePhenotypes.PhenotypesMSDDLTEXT);
                param.Add("@CaseId", casePhenotypes.CaseId);
                param.Add("@CreatedBy", casePhenotypes.CreatedBy);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spinsertCasePhenotypes(@PhenotypesMSDDL,@PhenotypesMSDDLTEXT,@CaseId,@CreatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To add the Case GeneList Details
        /// </summary>
        /// <param name="0"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddCaseGeneList(CaseGeneList caseGeneList)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@GeneList", caseGeneList.GeneList);
                param.Add("@GeneListTEXT", caseGeneList.GeneListTEXT);
                param.Add("@InvalidGeneList", caseGeneList.InvalidGeneList);
                param.Add("@FileUploadedPath", caseGeneList.FileUploadedPath);
                param.Add("@CaseId", caseGeneList.CaseId);
                param.Add("@CreatedBy", caseGeneList.CreatedBy);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spinsertCaseGeneList(@GeneList,@GeneListTEXT,@InvalidGeneList,@FileUploadedPath,@CaseId,@CreatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To add the Case FamilyTree Details
        /// </summary>
        /// <param name="AddCaseFamilyTree"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddCaseFamilyTree(CaseFamilyTree caseFamilyTree)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@CaseId", caseFamilyTree.CaseId);
                param.Add("@FamilyMemberType", caseFamilyTree.FamilyMemberType);
                param.Add("@AccessionID", caseFamilyTree.AccessionID);
                param.Add("@GenderId", caseFamilyTree.GenderId);
                param.Add("@IsAffected", caseFamilyTree.IsAffected);
                param.Add("@FASTQFileUploadedPath", caseFamilyTree.FASTQFileUploadedPath);
                param.Add("@ProjectVCFFileUploadedPath", caseFamilyTree.ProjectVCFFileUploadedPath);
                param.Add("@VCFFileUploadedPath", caseFamilyTree.VCFFileUploadedPath);
                param.Add("@BAMFileUploadedPath", caseFamilyTree.BAMFileUploadedPath);
                param.Add("@CreatedBy", caseFamilyTree.CreatedBy);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spinsertCaseFamilyTree(@CaseId,@FamilyMemberType,
                                        @AccessionID,@GenderId,@IsAffected,
                                        @FASTQFileUploadedPath,@ProjectVCFFileUploadedPath,
                                        @VCFFileUploadedPath,@BAMFileUploadedPath,
                                        @CreatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To GetCaseDetailsByStatusId
        /// </summary>
        /// <param name="GetCaseDetailsByStatusId"></param>
        /// <returns>data CaseDetails By StatusId </returns>
        public async Task<List<CaseDetails>> GetCaseDetailsByStatusId(int statusId)
        {
            List<CaseDetails> drivers = null;
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@StatusId", statusId);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select cd.CaseId,cd.ClientId,mc.clientname,CaseName,TestName,cd.AssayId,am.assayname,
                                    cd.AnalysisTypesIdMSDDL,    
                                    to_char(DueDate, 'MM/DD/YYYY') as DueDate,
                                    CaseNotes,cd.StatusId,csm.status,STAT,
                                    cd.FlagId,cfm.flag,cd.CreatedBy,cd.Createddate,cd.UpdatedBy,cd.Updateddate 
                                    from Case_Details cd 
                                    left join master_client mc on cd.clientid=mc.clientid
                                    left join assay_master am on cd.assayid=am.assayid
                                    left join Case_Status_Master csm on cd.StatusId=csm.StatusId
                                    left join Case_Flag_Master cfm on cd.flagid=cfm.flagid 
                                    where cd.StatusId=@StatusId
                                    order by cd.FlagId;";

                    var driverList = await dbConnection.QueryAsync<CaseDetails>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To GetCaseSectionsDataByCaseId
        /// </summary>
        /// <param name="GetCaseSectionsDataByCaseId"></param>
        /// <returns>data CaseSectionsData </returns>
        public async Task<CaseSectionsData> GetCaseSectionsDataByCaseId(int caseId)
        {
            CaseSectionsData caseSectionsData = new CaseSectionsData();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@CaseId", caseId);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    var querySQL = "";
                    // 1 CaseDetails
                    CaseDetails caseDetails = new CaseDetails();
                    querySQL = @"select cd.CaseId,cd.ClientId,mc.clientname,CaseName,TestName,cd.AssayId,am.assayname,
                                    cd.AnalysisTypesIdMSDDL,                                                                                                        
                                    to_char(DueDate, 'MM/DD/YYYY') as DueDate,CaseNotes,cd.StatusId,csm.status,STAT,
                                    cd.FlagId,cfm.flag,cd.CreatedBy,cd.Createddate,cd.UpdatedBy,cd.Updateddate 
                                    from Case_Details cd 
                                    left join master_client mc on cd.clientid=mc.clientid
                                    left join assay_master am on cd.assayid=am.assayid
                                    left join Case_Status_Master csm on cd.StatusId=csm.StatusId
                                    left join Case_Flag_Master cfm on cd.flagid=cfm.flagid 
                                    where cd.CaseId=@CaseId;";

                    var driverListCaseDetails = await dbConnection.QueryAsync<CaseDetails>(querySQL, param, commandType: CommandType.Text);
                    caseDetails = driverListCaseDetails.FirstOrDefault();
                    caseSectionsData.caseDetails = caseDetails;

                    // 2 ProbandInformation
                    CaseProbandInformation caseProbandInformation = new CaseProbandInformation();
                    querySQL = @"select 
                            CaseProbandInformationId,AccessionId,cpi.CaseId,cpi.GenderId,cgm.gender,
                            to_char(DateOfBirth, 'MM/DD/YYYY') as DateOfBirth,Age,Ethnicity,cpi.ConsanguinityId,ccm.Consanguinity,
                            cpi.CreatedBy,cpi.Createddate,cpi.UpdatedBy,cpi.Updateddate 
                            from Case_ProbandInformation cpi
                            left join Case_Gender_Master cgm on cpi.genderid=cgm.genderid
                            left join Case_Consanguinity_Master ccm on cpi.ConsanguinityId=ccm.ConsanguinityId
                            where cpi.CaseId=@CaseId;";
                    
                    var driverListCaseProbandInformation = await dbConnection.QueryAsync<CaseProbandInformation>(querySQL, param, commandType: CommandType.Text);
                    caseProbandInformation = driverListCaseProbandInformation.FirstOrDefault();
                    caseSectionsData.caseProbandInformation = caseProbandInformation;

                    // 3 Phenotypes
                    CasePhenotypes casePhenotypes = new CasePhenotypes();
                    querySQL = @"select CasePhenotypeId,PhenotypesMSDDL,PhenotypesMSDDLTEXT,CaseId,
                            CreatedBy,Createddate,UpdatedBy,Updateddate 
                            from Case_Phenotypes cp
                            where cp.CaseId=@CaseId;";
                    
                    var driverListCasePhenotypes = await dbConnection.QueryAsync<CasePhenotypes>(querySQL, param, commandType: CommandType.Text);
                    casePhenotypes = driverListCasePhenotypes.FirstOrDefault();
                    caseSectionsData.casePhenotypes = casePhenotypes;

                    // 4 GeneList
                    CaseGeneList caseGeneList = new CaseGeneList();
                    querySQL = @"select CaseGeneListId,GeneList,GeneListTEXT,InvalidGeneList,FileUploadedPath,CaseId,
                            CreatedBy,Createddate,UpdatedBy,Updateddate 
                            from Case_GeneList where CaseId=@CaseId;";
                    
                    var driverListCaseGeneList = await dbConnection.QueryAsync<CaseGeneList>(querySQL, param, commandType: CommandType.Text);
                    caseGeneList = driverListCaseGeneList.FirstOrDefault();
                    caseSectionsData.caseGeneList = caseGeneList;

                    // 5 FamilyTree
                    List<CaseFamilyTree> caseFamilyTree = new List<CaseFamilyTree>();

                    querySQL = @"select CaseFamilyTreeId,cft.CaseId,FamilyMemberType,AccessionID,
                            cft.GenderId,cgm.gender,IsAffected,
                            FASTQFileUploadedPath,ProjectVCFFileUploadedPath,VCFFileUploadedPath,BAMFileUploadedPath,
                            cft.CreatedBy,cft.Createddate,cft.UpdatedBy,cft.Updateddate 
                            from Case_FamilyTree cft
                            left join Case_Gender_Master cgm on cft.genderid=cgm.genderid 
                            where cft.CaseId=@CaseId
                            ORDER BY case when upper(FamilyMemberType) = 'PROBAND' then 1
                            when upper(FamilyMemberType) = 'MOTHER' then 2
                            when upper(FamilyMemberType) = 'FATHER' then 3
                            when upper(FamilyMemberType) = 'SIBLING 1' then 4
                            when upper(FamilyMemberType) = 'SIBLING 2' then 5
                            else 6
                            end asc;";
                   
                    var driverListCaseFamilyTree = await dbConnection.QueryAsync<CaseFamilyTree>(querySQL, param, commandType: CommandType.Text);
                    caseFamilyTree = driverListCaseFamilyTree.ToList();
                    caseSectionsData.caseFamilyTree = caseFamilyTree;
                }
            }
            catch (Exception ex)
            {

            }
            return caseSectionsData;

        }

        /// <summary>
        /// To GetCaseDetailsByCaseId
        /// </summary>
        /// <param name="GetCaseDetailsByCaseId"></param>
        /// <returns>data CaseDetails By CaseId </returns>
        public async Task<CaseDetails> GetCaseDetailsByCaseId(int caseId)
        {
            CaseDetails caseDetails = new CaseDetails();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@CaseId", caseId);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select 
                            CaseId,ClientId,CaseName,TestName,AssayId,
                            AnalysisTypesIdMSDDL,DueDate,
                            CaseNotes,StatusId,STAT,FlagId,
                            CreatedBy,Createddate,UpdatedBy,Updateddate 
                            from Case_Details where CaseId=@CaseId;";

                    var driverCaseDetails = await dbConnection.QueryAsync<CaseDetails>(querySQL, param, commandType: CommandType.Text);
                    caseDetails = driverCaseDetails.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }

            return caseDetails;
        }

        /// <summary>
        /// To GetCaseProbandInformationByCaseId
        /// </summary>
        /// <param name="GetCaseProbandInformationByCaseId"></param>
        /// <returns>data CaseProbandInformation By CaseId </returns>
        public async Task<CaseProbandInformation> GetCaseProbandInformationByCaseId(int caseId)
        {
            CaseProbandInformation caseProbandInformation = new CaseProbandInformation();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@CaseId", caseId);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select 
                            CaseProbandInformationId,AccessionId,CaseId,GenderId,
                            DateOfBirth,Age,Ethnicity,ConsanguinityId,
                            CreatedBy,Createddate,UpdatedBy,Updateddate 
                            from Case_ProbandInformation where CaseId=@CaseId;";

                    var driverCaseProbandInformation = await dbConnection.QueryAsync<CaseProbandInformation>(querySQL, param, commandType: CommandType.Text);
                    caseProbandInformation = driverCaseProbandInformation.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }

            return caseProbandInformation;
        }

        /// <summary>
        /// To GetCasePhenotypesByCaseId
        /// </summary>
        /// <param name="GetCasePhenotypesByCaseId"></param>
        /// <returns>data CasePhenotypes By CaseId </returns>
        public async Task<CasePhenotypes> GetCasePhenotypesByCaseId(int caseId)
        {
            CasePhenotypes casePhenotypes = new CasePhenotypes();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@CaseId", caseId);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select CasePhenotypeId,PhenotypesMSDDL,PhenotypesMSDDLTEXT,CaseId,
                            CreatedBy,Createddate,UpdatedBy,Updateddate 
                            from Case_Phenotypes where CaseId=@CaseId;";
 
                    var driverCasePhenotypes = await dbConnection.QueryAsync<CasePhenotypes>(querySQL, param, commandType: CommandType.Text);
                    casePhenotypes = driverCasePhenotypes.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }

            return casePhenotypes;
        }

        /// <summary>
        /// To GetCaseGeneListByCaseId
        /// </summary>
        /// <param name="GetCaseGeneListByCaseId"></param>
        /// <returns>data CaseGeneList By CaseId </returns>
        public async Task<CaseGeneList> GetCaseGeneListByCaseId(int caseId)
        {
            CaseGeneList caseGeneList = new CaseGeneList();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@CaseId", caseId);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select CaseGeneListId,GeneList,GeneListTEXT,InvalidGeneList,FileUploadedPath,CaseId,
                            CreatedBy,Createddate,UpdatedBy,Updateddate 
                            from Case_GeneList where CaseId=@CaseId;";
 
                    var driverCaseGeneList = await dbConnection.QueryAsync<CaseGeneList>(querySQL, param, commandType: CommandType.Text);
                    caseGeneList = driverCaseGeneList.FirstOrDefault();
                }
            }
            catch (Exception e)
            {
            }

            return caseGeneList;
        }

        /// <summary>
        /// To GetCaseFamilyTreeByCaseId
        /// </summary>
        /// <param name="GetCaseFamilyTreeByCaseId"></param>
        /// <returns>data CaseFamilyTree By CaseId </returns>
        public async Task<List<CaseFamilyTree>> GetCaseFamilyTreeByCaseId(int caseId)
        {
            List<CaseFamilyTree> caseFamilyTree = new List<CaseFamilyTree>();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@CaseId", caseId);

                using (DbConnection dbConnection = SqlWriterConnection)
                {

                    var querySQL = @"select CaseFamilyTreeId,CaseId,FamilyMemberType,AccessionID,
                            GenderId,IsAffected,FASTQFileUploadedPath,ProjectVCFFileUploadedPath,VCFFileUploadedPath,BAMFileUploadedPath,
                            CreatedBy,Createddate,UpdatedBy,Updateddate 
                            from Case_FamilyTree where CaseId=@CaseId
                            ORDER BY case when upper(FamilyMemberType) = 'PROBAND' then 1
                            when upper(FamilyMemberType) = 'MOTHER' then 2
                            when upper(FamilyMemberType) = 'FATHER' then 3
                            when upper(FamilyMemberType) = 'SIBLING 1' then 4
                            when upper(FamilyMemberType) = 'SIBLING 2' then 5
                            else 6
                            end asc;";

                    var driverListCaseFamilyTree = await dbConnection.QueryAsync<CaseFamilyTree>(querySQL, param, commandType: CommandType.Text);
                    caseFamilyTree = driverListCaseFamilyTree.ToList();
                }
            }
            catch (Exception e)
            {
            }
            return caseFamilyTree;
        }


        /// <summary>
        /// To update the CaseNotes
        /// </summary>
        /// <param name="UpdateCaseNotes"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateCaseNotes(CaseDetails caseDetails)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@CaseId", caseDetails.CaseId);
                param.Add("@CaseNotes", caseDetails.CaseNotes);
                param.Add("@UpdatedBy", caseDetails.UpdatedBy);

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdateCaseNotes(@CaseId,@CaseNotes,@UpdatedBy);";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }




    }
}
