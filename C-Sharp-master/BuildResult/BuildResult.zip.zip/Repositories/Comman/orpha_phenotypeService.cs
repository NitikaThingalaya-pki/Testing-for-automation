﻿using Dapper;
using ODIN2_API.Repositories.Interface.Comman;
using ODIN2_Modules.Comman;
using System.Data;
using System.Data.Common;


namespace ODIN2_API.Repositories.Comman
{
    public class orpha_phenotypeService : BaseAsyncRepository, Iorpha_phenotype
    {
        public orpha_phenotypeService(IConfiguration configuration) : base(configuration)
        {
        }
        
        public async Task<List<orphanetphenotype>> GetAllorphanetPhenotype(string SearchGeneSymbol)
        {
            List<orphanetphenotype> drivers = null;
            orphanetphenotype objGeneSymbolSearch = new orphanetphenotype();
            var querySQL = "";

            try
            {
                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    DynamicParameters param = new DynamicParameters();
                    string term = "%" + SearchGeneSymbol + "%";
                    param.Add("@searchorpha", term);
                   
                    querySQL = @"select top 10 orpha_id,orpha_phenotype from public_orphanet_hgncid where  orpha_phenotype  like @searchorpha";
                    var driverListcase1 = await dbConnection.QueryAsync<orphanetphenotype>(querySQL, param, commandType: CommandType.Text);
                    drivers = driverListcase1.ToList();





                }
            }
            catch (Exception e)
            {
            }


            return drivers;
        }
    }
}
