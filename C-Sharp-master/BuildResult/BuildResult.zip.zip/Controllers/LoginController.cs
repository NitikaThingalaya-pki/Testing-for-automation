﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginAsyncRepository _loginAsyncRepository;

        public LoginController(ILoginAsyncRepository loginAsyncRepository)
        {

            _loginAsyncRepository = loginAsyncRepository;

        }
        /// <summary>
        /// gets the statuscode from AuthenticateUser method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="_login"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AuthenticateUser")]
        public async Task<ActionResult> AuthenticateUser([FromBody]Login login)
        {

         

            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _loginAsyncRepository.AuthenticateUser(login);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
                responseDetails.ResponseData = driver[0].ResponseData.ToString();
            }

            return Ok(responseDetails);

        }
    }
}
