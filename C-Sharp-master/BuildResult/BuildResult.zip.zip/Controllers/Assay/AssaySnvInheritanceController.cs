﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]
    public class AssaySnvInheritanceController : ControllerBase
    {
        private readonly IAssaySnvInheritanceService _assaySnvInheritanceService;

        public AssaySnvInheritanceController(IAssaySnvInheritanceService assaySnvInheritanceService)
        {
            _assaySnvInheritanceService = assaySnvInheritanceService;
        }

        /// <summary>
        /// gets the statuscode from AddAssaySnvInheritance method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addAssaySnvInheritance"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddAssaySnvInheritance")]
        [ActionName("AddAssaySnvInheritance"), Authorize]
        public async Task<ActionResult> AddAssaySnvInheritance([FromBody] AssaySnvInheritance assaySnvInheritance)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvInheritanceService.AddAssaySnvInheritance(assaySnvInheritance);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            return Ok(responseDetails);

        }


        [HttpGet]
        [Route("GetAssaySnvInheritanceById/{tabId}&{assayId}")]
        [ActionName("GetAssaySnvInheritanceById"), Authorize]
        public async Task<ActionResult> GetAssaySnvInheritanceById(int tabId, int assayId)
        {
            var driver = await _assaySnvInheritanceService.GetAssaySnvInheritanceById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("AssaySnvInheritance Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateAssaySnvInheritance")]
        [ActionName("UpdateAssaySnvInheritance"), Authorize]
        public async Task<ActionResult> UpdateAssaySnvInheritance([FromBody] AssaySnvInheritance assaySnvInheritance)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _assaySnvInheritanceService.UpdateAssaySnvInheritance(assaySnvInheritance);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }

    }
}
