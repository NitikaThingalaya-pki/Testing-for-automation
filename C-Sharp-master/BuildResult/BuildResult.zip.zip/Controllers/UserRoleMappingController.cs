﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Controllers
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class UserRoleMappingController : ControllerBase
    {
        private readonly IUserRoleMappingService _userRoleMappingService;

        public UserRoleMappingController(IUserRoleMappingService userRoleMappingService)
        {

            _userRoleMappingService = userRoleMappingService;

        }

        /// <summary>
        /// gets the statuscode from AddUserRoleMapping method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="adduserrolemapping"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddUserRoleMapping")]
        [ActionName("AddUserRoleMapping"), Authorize]
        public async Task<ActionResult> AddUserRoleMapping([FromBody] UserRoleMapping userRoleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _userRoleMappingService.AddUserRoleMapping(userRoleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpPost]
        [Route("UpdateUserRoleMapping")]
        [ActionName("UpdateUserRoleMapping"), Authorize]
        public async Task<ActionResult> UpdateUserRoleMapping([FromBody] UserRoleMapping userRoleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _userRoleMappingService.UpdateUserRoleMapping(userRoleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }


        [HttpPost]
        [Route("DeleteUserRoleMappingById")]
        [ActionName("DeleteUserRoleMappingById"), Authorize]
        public async Task<ActionResult> DeleteUserRoleMappingById([FromBody] UserRoleMapping userRoleMapping)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _userRoleMappingService.DeleteUserRoleMappingById(userRoleMapping);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);

        }

        [HttpGet]
        [Route("GetUserRoleMappingById/{userRoleMappingId}")]
        [ActionName("GetUserRoleMappingById"), Authorize]
        public async Task<ActionResult> GetUserRoleMappingById(int userRoleMappingId)
        {
            var driver = await _userRoleMappingService.GetUserRoleMappingById(userRoleMappingId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All User Role Mapping Data By Id");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetAllUserRoleMapping")]
        [ActionName("GetAllUserRoleMapping"), Authorize]
        public async Task<ActionResult> GetAllUserRoleMapping()
        {

            var driver = await _userRoleMappingService.GetAllUserRoleMapping();
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("All UserRole Mapping Data");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);

        }

    }
}
