﻿using ODIN2_Modules;

namespace ODIN2_API.Repositories.Interface
{
    public interface IRoleModuleMappingService
    {
        Task<List<BaseResponseStatus>> DeleteRole(RoleModuleMapping rolemodulemapping);
        Task<List<BaseResponseStatus>> UpdateRole(RoleModuleMapping rolemodulemapping);
        Task<List<BaseResponseStatus>> AddRole(RoleModuleMapping rolemodulemapping);
        Task<List<BaseResponseStatus>> AddRoleModuleMapping(RoleModuleMapping rolemodulemapping);
        Task<List<BaseResponseStatus>> UpdateRoleModuleMapping(RoleModuleMapping rolemodulemapping);
        Task<List<BaseResponseStatus>> DeleteRoleModuleMappingById(RoleModuleMapping rolemodulemapping);
        Task<List<RoleModuleMapping>> GetRoleModuleMappingById(int roleModuleMappingId);
        Task<List<RoleModuleMapping>> GetAllRoleModuleMapping();

        Task<List<RoleModuleMapping>> GetMenuPermission();
        Task<List<RoleModuleMapping>> GetRoleModuleMappingList();


        

    }
}
