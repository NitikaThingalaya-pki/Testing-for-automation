﻿using System.Data;
using System.Data.Common;
using Dapper;
using ODIN2_API.Repositories.Interface;
using ODIN2_Modules;

namespace ODIN2_API.Repositories
{
    public class RoleModuleMappingService : BaseAsyncRepository, IRoleModuleMappingService
    {

        public RoleModuleMappingService(IConfiguration configuration) : base(configuration)
        {
        }


        public async Task<List<BaseResponseStatus>> AddRole(RoleModuleMapping rolemodulemapping)
        {
            List<BaseResponseStatus> drivers = null;
            List<BaseResponseStatus> drivers2 = null;
            int roleid = 0;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spinsertrole('" + rolemodulemapping.role + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                    if (rolemodulemapping.roleIdArray != null)
                    {
                        string[] values = rolemodulemapping.roleIdArray.Split(',');
                        if (drivers[0].StatusCode == "200")
                        {
                            roleid = Convert.ToInt32(drivers[0].ResponseData);
                            foreach (string str in values)
                            {
                                string[] value = str.Split('-');


                                var querySQL2 = @"call spInsertRoleModuleMapping('" + roleid + "','" + value[0] + "','" + value[1] + "','" + rolemodulemapping.CreatedBy + "');";
                                var driverList2 = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL2, null, commandType: CommandType.Text);
                                drivers2 = driverList2.ToList();

                            }



                        }
                    }

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


        public async Task<List<BaseResponseStatus>> UpdateRole(RoleModuleMapping rolemodulemapping)
        {
            List<BaseResponseStatus> drivers = null;
            List<BaseResponseStatus> drivers2 = null;
            int roleid = 0;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spupdaterole('" + rolemodulemapping.RoleId + "','" + rolemodulemapping.role + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                    if (rolemodulemapping.roleIdArray != null)
                    {
                        string[] values = rolemodulemapping.roleIdArray.Split(',');
                        if (drivers[0].StatusCode == "200")
                        {
                            roleid = rolemodulemapping.RoleId;
                            foreach (string str in values)
                            {
                                string[] value = str.Split('-');


                                var querySQL2 = @"call spupdaterolemodulemapping('" + roleid + "', '" + value[0] + "','" + value[1] + "','" + rolemodulemapping.CreatedBy + "');";
                                var driverList2 = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL2, null, commandType: CommandType.Text);
                                drivers2 = driverList2.ToList();

                            }



                        }
                    }

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        public async Task<List<BaseResponseStatus>> DeleteRole(RoleModuleMapping rolemodulemapping)
        {
            List<BaseResponseStatus> drivers = null;
            List<BaseResponseStatus> drivers2 = null;
            int roleid = 0;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spdeleterolebyid('" + rolemodulemapping.DRoleId + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();
                                     

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


        /// <summary>
        /// To add the rolemodulemapping 
        /// </summary>
        /// <param name="addrolemodulemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> AddRoleModuleMapping(RoleModuleMapping rolemodulemapping)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spInsertRoleModuleMapping('" + rolemodulemapping.RoleId + "','" + rolemodulemapping.ModuleId+ "','" + rolemodulemapping.SubModuleId + "','" + rolemodulemapping.CreatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To update the rolemodulemapping 
        /// </summary>
        /// <param name="updaterolemodulemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> UpdateRoleModuleMapping(RoleModuleMapping rolemodulemapping)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spUpdateRoleModuleMapping('" + rolemodulemapping.RoleId + "','" + rolemodulemapping.ModuleId + "','" + rolemodulemapping.SubModuleId + "','" + rolemodulemapping.RoleModuleMappingId + "','" + rolemodulemapping.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To delete the rolemodulemapping by id
        /// </summary>
        /// <param name="deleterolemodulemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<BaseResponseStatus>> DeleteRoleModuleMappingById(RoleModuleMapping rolemodulemapping)
        {
            List<BaseResponseStatus> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"call spDeleteRoleModuleMappingById('" + rolemodulemapping.RoleModuleMappingId + "','" + rolemodulemapping.UpdatedBy + "');";
                    var driverList = await dbConnection.QueryAsync<BaseResponseStatus>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }
        /// <summary>
        /// To get the rolemodulemapping 
        /// </summary>
        /// <param name="getallrolemodulemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<RoleModuleMapping>> GetAllRoleModuleMapping()
        {
            List<RoleModuleMapping> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    //var querySQL = @"select rolemodulemappingid,RoleId,ModuleId,SubModuleId,isactive,createdby,createddate,updatedby,updateddate from master_Rolemodulemapping;";
                    var querySQL = @"with CTE as (
                                                    select moduleid, 0 as submoduleid, 'Y' as IsparentMenu, modulename   from master_module ms 
                                                    union all 
                                                    select moduleid, submoduleid as submoduleid,'N' as IsparentMenu, submodulename from master_submodule ms 
                                                    )
                                                    select *,  
                                                    moduleid ||  '-' || submoduleid as mapping
                                                    from CTE
                                                    order by moduleid, submoduleid;";
                    var driverList = await dbConnection.QueryAsync<RoleModuleMapping>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To get the rolemodulemapping 
        /// </summary>
        /// <param name="getallrolemodulemapping"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<RoleModuleMapping>> GetRoleModuleMappingList()
        {
            List<RoleModuleMapping> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    //var querySQL = @"select rolemodulemappingid,RoleId,ModuleId,SubModuleId,isactive,createdby,createddate,updatedby,updateddate from master_Rolemodulemapping;";
                    var querySQL = @"
                                    select roleid, role,
                                    (select count(1) from master_users u where roleid=mr.roleid  and isactive =1) as rolecount,
                                    (select listagg(moduleid ||  '-' || submoduleid, ',') from master_rolemodulemapping where roleid=mr.roleid) as editmoduleid,
                                    (select listagg(submodulename, ',') from master_rolemodulemapping m inner join master_submodule s on m.submoduleid = s.submoduleid  where roleid=mr.roleid) as permission,
                                    (select listagg(modulename ||  '$' ||submodulename, ',') from master_rolemodulemapping m inner join master_submodule s on m.submoduleid = s.submoduleid  inner join master_module mm on m.moduleid  = mm.moduleid where roleid=mr.roleid) as permissionall
                                    from master_roles mr  where Isactive=true 
                                    ;";
                    var driverList = await dbConnection.QueryAsync<RoleModuleMapping>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }


        public async Task<List<RoleModuleMapping>> GetMenuPermission()
        {
            List<RoleModuleMapping> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();
                    
                    //var querySQL = @"select rolemodulemappingid,RoleId,ModuleId,SubModuleId,isactive,createdby,createddate,updatedby,updateddate from master_Rolemodulemapping;";
                    var querySQL = @"
                                    select *, mr.role , username as [createdby] from master_users mu 
                                    inner join master_roles mr  
                                    on mu.roleid  = mr.roleid 
                                    inner join master_rolemodulemapping mr2 
                                    on mr.roleid = mr2.roleid 
                                    inner join master_module mm 
                                      on mm.moduleid  = mr2.moduleid 
                                      where 
                                       mm.modulename = 'Manage Roles'
                                    ;";
                    var driverList = await dbConnection.QueryAsync<RoleModuleMapping>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        /// <summary>
        /// To add the rolemodulemapping by id
        /// </summary>
        /// <param name="getrolemodulemappingbyid"></param>
        /// <returns>statuscode and statusmessage</returns>
        public async Task<List<RoleModuleMapping>> GetRoleModuleMappingById(int roleModuleMappingId)
        {
            List<RoleModuleMapping> drivers = null;
            try
            {

                using (DbConnection dbConnection = SqlWriterConnection)
                {
                    await dbConnection.OpenAsync();

                    var querySQL = @"select rolemodulemappingid,RoleId,ModuleId,SubModuleId,isactive,createdby,createddate,updatedby,updateddate from master_Rolemodulemapping where rolemodulemappingid=" + roleModuleMappingId +";";
                    var driverList = await dbConnection.QueryAsync<RoleModuleMapping>(querySQL, null, commandType: CommandType.Text);
                    drivers = driverList.ToList();

                }
            }
            catch (Exception e)
            {
            }

            return drivers;
        }

        
    }
}
