﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODIN2_API.Repositories.Interface;
using ODIN2_API.Repositories.Interface.Assay;
using ODIN2_Modules;
using ODIN2_Modules.Assay;

namespace ODIN2_API.Controllers.Assay
{
    [Route("odinapi/[controller]")]
    [ApiController]

    public class TabController : ControllerBase
    {
        private readonly ITabService _tabService;

        public TabController(ITabService tabService)
        {
            _tabService = tabService;
        }

        /// <summary>
        /// gets the statuscode from Addtab method and accordingly sets the statusmessage
        /// </summary>
        /// <param name="addtab"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddTab")]
        [ActionName("AddTab"), Authorize]
        public async Task<ActionResult> AddTab([FromBody] MasterTab tab)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _tabService.AddTab(tab);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage;
                responseDetails.ResponseData = driver[0].ResponseData;
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage;
                responseDetails.ResponseData = driver[0].ResponseData;
            }
            return Ok(responseDetails);
        }

        [HttpPost]
        [Route("UpdateTab")]
        [ActionName("UpdateTab"), Authorize]
        public async Task<ActionResult> UpdateTab([FromBody] MasterTab tab)
        {
            BaseResponseStatus responseDetails = new BaseResponseStatus();

            var driver = await _tabService.UpdateTab(tab);
            if (driver[0].StatusCode.ToString() == "404")
            {
                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }
            else
            {
                responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
                responseDetails.StatusMessage = driver[0].StatusMessage.ToString();
            }

            return Ok(responseDetails);
        }

        [HttpGet]
        [Route("GetTabById/{tabId}&{assayId}")]
        [ActionName("GetTabById"), Authorize]
        public async Task<ActionResult> GetTabById(int tabId, int assayId)
        {
            var driver = await _tabService.GetTabById(tabId, assayId);
            BaseResponseStatus responseDetails = new BaseResponseStatus();
            if (driver == null)
            {
                var returnMsg = string.Format("Tab Data By TabId and AssayId");

                responseDetails.StatusCode = StatusCodes.Status404NotFound.ToString();
                responseDetails.StatusMessage = returnMsg;
                return Ok(responseDetails);
            }

            responseDetails.StatusCode = StatusCodes.Status200OK.ToString();
            responseDetails.StatusMessage = "Data fetched successfully";
            responseDetails.ResponseData = driver;
            return Ok(responseDetails);
        }


    }
}
